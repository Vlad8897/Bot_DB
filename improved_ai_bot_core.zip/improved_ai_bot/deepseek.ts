import { DatabaseService } from './database';

// Интерфейс для запроса к DeepSeek API
export interface DeepSeekRequest {
  model: string;
  messages: Array<{
    role: 'system' | 'user' | 'assistant';
    content: string;
  }>;
  temperature?: number;
  max_tokens?: number;
}

// Интерфейс для ответа от DeepSeek API
export interface DeepSeekResponse {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: Array<{
    index: number;
    message: {
      role: string;
      content: string;
    };
    finish_reason: string;
  }>;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

// Класс для работы с DeepSeek API
export class DeepSeekService {
  private apiKey: string;
  private apiBaseUrl: string;
  private model: string;
  
  constructor(apiKey: string, apiBaseUrl: string = 'https://api.deepseek.com', model: string = 'deepseek-chat') {
    this.apiKey = apiKey;
    this.apiBaseUrl = apiBaseUrl;
    this.model = model;
  }
  
  // Метод для вызова DeepSeek API
  async callAPI(messages: Array<{role: 'system' | 'user' | 'assistant', content: string}>, options: {
    temperature?: number;
    max_tokens?: number;
  } = {}): Promise<DeepSeekResponse> {
    try {
      const url = `${this.apiBaseUrl}/v1/chat/completions`;
      
      const requestBody: DeepSeekRequest = {
        model: this.model,
        messages,
        temperature: options.temperature ?? 0.7,
        max_tokens: options.max_tokens ?? 1000
      };
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify(requestBody)
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`DeepSeek API error: ${response.status} - ${errorText}`);
      }
      
      return await response.json() as DeepSeekResponse;
    } catch (error) {
      console.error('Error calling DeepSeek API:', error);
      
      // Возвращаем имитацию ответа в случае ошибки
      const userMessage = messages.find(msg => msg.role === 'user')?.content || '';
      const responseContent = `Произошла ошибка при обращении к API DeepSeek. Пожалуйста, попробуйте позже.`;
      
      return {
        id: `error-${Date.now()}`,
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        model: this.model,
        choices: [
          {
            index: 0,
            message: {
              role: 'assistant',
              content: responseContent
            },
            finish_reason: 'stop'
          }
        ],
        usage: {
          prompt_tokens: userMessage.length,
          completion_tokens: responseContent.length,
          total_tokens: userMessage.length + responseContent.length
        }
      };
    }
  }
  
  // Метод для генерации векторного представления текста
  async generateEmbedding(text: string): Promise<number[]> {
    try {
      const url = `${this.apiBaseUrl}/embeddings`;
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'deepseek-embedding',
          input: text
        })
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`DeepSeek API error: ${response.status} - ${errorText}`);
      }
      
      const result = await response.json();
      return result.data[0].embedding;
    } catch (error) {
      console.error('Error generating embedding:', error);
      
      // Возвращаем случайный вектор в случае ошибки
      return Array.from({ length: 1536 }, () => Math.random());
    }
  }
}

// Класс для интеграции DeepSeek с базой данных
export class BotService {
  private deepSeek: DeepSeekService;
  private db: DatabaseService;
  
  constructor(deepSeek: DeepSeekService, db: DatabaseService) {
    this.deepSeek = deepSeek;
    this.db = db;
  }
  
  // Метод для обработки запроса пользователя
  async processQuery(query: string, userId?: string, sessionId?: string): Promise<{
    response: string;
    sources?: Array<{
      id: string;
      title: string;
      content: string;
      relevance: number;
    }>;
    sessionId: string;
  }> {
    // Генерация ID сессии, если он не предоставлен
    const actualSessionId = sessionId || `session_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    
    // Поиск релевантных документов
    const documents = await this.db.searchDocuments(query);
    
    // Формирование запроса к DeepSeek API
    const messages = [
      {
        role: 'system' as const,
        content: 'Вы бот на основе DeepSeek с интеграцией базы данных. Вы помогаете пользователям находить информацию и отвечаете на их вопросы.'
      },
      {
        role: 'user' as const,
        content: query
      }
    ];
    
    // Если найдены релевантные документы, добавляем их в контекст
    if (documents.length > 0) {
      const contextMessage = {
        role: 'system' as const,
        content: `Релевантные документы:\n${documents.map(doc => `Документ "${doc.title}":\n${doc.content}`).join('\n\n')}`
      };
      messages.splice(1, 0, contextMessage);
    }
    
    // Вызов DeepSeek API
    const response = await this.deepSeek.callAPI(messages, {
      temperature: 0.7,
      max_tokens: 1000
    });
    
    // Получение ответа от DeepSeek
    const botResponse = response.choices[0].message.content;
    
    // Сохранение запроса и ответа в базе данных
    const queryId = await this.db.saveQuery({
      user_id: userId,
      session_id: actualSessionId,
      query,
      response: botResponse
    });
    
    // Сохранение источников для запроса
    const sources = [];
    for (const doc of documents) {
      // Вычисление релевантности (в реальном приложении будет использоваться векторное сходство)
      const relevance = Math.random() * 0.5 + 0.5; // Случайное значение от 0.5 до 1.0
      
      // Сохранение источника
      await this.db.saveSource({
        query_id: queryId,
        document_id: doc.id,
        relevance
      });
      
      // Добавление источника в результат
      sources.push({
        id: doc.id,
        title: doc.title,
        content: doc.content,
        relevance
      });
    }
    
    // Формирование результата
    return {
      response: botResponse,
      sources: sources.length > 0 ? sources : undefined,
      sessionId: actualSessionId
    };
  }
}
