"""
Модели данных для векторного хранилища документов и аудиофайлов.
Включает модели для хранения документов, аудиофайлов, категорий, тегов и истории запросов.
"""

from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Float, Boolean, Table
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import JSONB, ARRAY
from sqlalchemy.sql import func
from datetime import datetime
import uuid

from .base import Base

# Таблица связи между документами и тегами
document_tags = Table(
    'document_tags',
    Base.metadata,
    Column('document_id', Integer, ForeignKey('documents.id'), primary_key=True),
    Column('tag_id', Integer, ForeignKey('tags.id'), primary_key=True)
)

# Таблица связи между аудиофайлами и тегами
audio_tags = Table(
    'audio_tags',
    Base.metadata,
    Column('audio_id', Integer, ForeignKey('audio_files.id'), primary_key=True),
    Column('tag_id', Integer, ForeignKey('tags.id'), primary_key=True)
)

class Category(Base):
    """Модель для категорий документов и аудиофайлов."""
    __tablename__ = 'categories'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False, unique=True)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Отношения
    documents = relationship("Document", back_populates="category")
    audio_files = relationship("AudioFile", back_populates="category")
    
    def __repr__(self):
        return f"<Category(id={self.id}, name='{self.name}')>"

class Tag(Base):
    """Модель для тегов документов и аудиофайлов."""
    __tablename__ = 'tags'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50), nullable=False, unique=True)
    created_at = Column(DateTime, default=func.now())
    
    # Отношения
    documents = relationship("Document", secondary=document_tags, back_populates="tags")
    audio_files = relationship("AudioFile", secondary=audio_tags, back_populates="tags")
    
    def __repr__(self):
        return f"<Tag(id={self.id}, name='{self.name}')>"

class Document(Base):
    """Модель для хранения документов с векторным представлением."""
    __tablename__ = 'documents'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    content = Column(Text, nullable=False)
    file_path = Column(String(255), nullable=True)  # Путь к исходному файлу
    file_type = Column(String(50), nullable=True)   # Тип файла (pdf, docx, txt и т.д.)
    metadata = Column(JSONB, nullable=True)         # Дополнительные метаданные
    vector_embedding = Column(ARRAY(Float), nullable=True)  # Векторное представление документа
    category_id = Column(Integer, ForeignKey('categories.id'), nullable=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Отношения
    category = relationship("Category", back_populates="documents")
    tags = relationship("Tag", secondary=document_tags, back_populates="documents")
    chunks = relationship("DocumentChunk", back_populates="document", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Document(id={self.id}, title='{self.title}')>"

class DocumentChunk(Base):
    """Модель для хранения фрагментов документов с векторным представлением."""
    __tablename__ = 'document_chunks'
    
    id = Column(Integer, primary_key=True)
    document_id = Column(Integer, ForeignKey('documents.id'), nullable=False)
    content = Column(Text, nullable=False)
    chunk_index = Column(Integer, nullable=False)  # Индекс фрагмента в документе
    vector_embedding = Column(ARRAY(Float), nullable=True)  # Векторное представление фрагмента
    metadata = Column(JSONB, nullable=True)  # Дополнительные метаданные
    created_at = Column(DateTime, default=func.now())
    
    # Отношения
    document = relationship("Document", back_populates="chunks")
    
    def __repr__(self):
        return f"<DocumentChunk(id={self.id}, document_id={self.document_id}, chunk_index={self.chunk_index})>"

class AudioFile(Base):
    """Модель для хранения аудиофайлов с векторным представлением транскрипции."""
    __tablename__ = 'audio_files'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    file_path = Column(String(255), nullable=False)  # Путь к аудиофайлу
    duration = Column(Float, nullable=True)  # Длительность в секундах
    transcription = Column(Text, nullable=True)  # Текстовая транскрипция
    vector_embedding = Column(ARRAY(Float), nullable=True)  # Векторное представление транскрипции
    metadata = Column(JSONB, nullable=True)  # Дополнительные метаданные (формат, битрейт и т.д.)
    category_id = Column(Integer, ForeignKey('categories.id'), nullable=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Отношения
    category = relationship("Category", back_populates="audio_files")
    tags = relationship("Tag", secondary=audio_tags, back_populates="audio_files")
    segments = relationship("AudioSegment", back_populates="audio_file", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<AudioFile(id={self.id}, title='{self.title}')>"

class AudioSegment(Base):
    """Модель для хранения сегментов аудиофайлов с информацией о говорящем."""
    __tablename__ = 'audio_segments'
    
    id = Column(Integer, primary_key=True)
    audio_id = Column(Integer, ForeignKey('audio_files.id'), nullable=False)
    start_time = Column(Float, nullable=False)  # Время начала сегмента в секундах
    end_time = Column(Float, nullable=False)    # Время окончания сегмента в секундах
    transcription = Column(Text, nullable=False)  # Текстовая транскрипция сегмента
    speaker_id = Column(String(50), nullable=True)  # Идентификатор говорящего
    confidence = Column(Float, nullable=True)  # Уверенность в транскрипции
    vector_embedding = Column(ARRAY(Float), nullable=True)  # Векторное представление сегмента
    emotion = Column(String(50), nullable=True)  # Определенная эмоция в речи
    created_at = Column(DateTime, default=func.now())
    
    # Отношения
    audio_file = relationship("AudioFile", back_populates="segments")
    
    def __repr__(self):
        return f"<AudioSegment(id={self.id}, audio_id={self.audio_id}, start_time={self.start_time}, end_time={self.end_time})>"

class UserQuery(Base):
    """Модель для хранения истории запросов пользователей."""
    __tablename__ = 'user_queries'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(String(100), nullable=True)  # Идентификатор пользователя (если есть)
    session_id = Column(String(100), nullable=False)  # Идентификатор сессии
    query_text = Column(Text, nullable=False)  # Текст запроса
    query_audio_path = Column(String(255), nullable=True)  # Путь к аудиофайлу запроса (если есть)
    response_text = Column(Text, nullable=True)  # Текст ответа
    response_audio_path = Column(String(255), nullable=True)  # Путь к аудиофайлу ответа (если есть)
    vector_embedding = Column(ARRAY(Float), nullable=True)  # Векторное представление запроса
    metadata = Column(JSONB, nullable=True)  # Дополнительные метаданные
    created_at = Column(DateTime, default=func.now())
    
    def __repr__(self):
        return f"<UserQuery(id={self.id}, query_text='{self.query_text[:30]}...')>"

class UserFeedback(Base):
    """Модель для хранения обратной связи от пользователей."""
    __tablename__ = 'user_feedback'
    
    id = Column(Integer, primary_key=True)
    query_id = Column(Integer, ForeignKey('user_queries.id'), nullable=False)
    rating = Column(Integer, nullable=False)  # Оценка от 1 до 5
    comment = Column(Text, nullable=True)  # Комментарий пользователя
    created_at = Column(DateTime, default=func.now())
    
    # Отношения
    query = relationship("UserQuery")
    
    def __repr__(self):
        return f"<UserFeedback(id={self.id}, query_id={self.query_id}, rating={self.rating})>"

class User(Base):
    """Модель для хранения информации о пользователях."""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(String(100), nullable=False, unique=True)  # Внешний идентификатор пользователя
    username = Column(String(100), nullable=True)
    email = Column(String(100), nullable=True)
    preferences = Column(JSONB, nullable=True)  # Пользовательские настройки
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    def __repr__(self):
        return f"<User(id={self.id}, username='{self.username}')>"
