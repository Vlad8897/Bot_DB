"""
База данных PostgreSQL с векторным хранилищем для AI бота.
Модуль содержит базовые классы и настройки для работы с базой данных.
"""

from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, ForeignKey, Float, Boolean, Table
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, scoped_session
from sqlalchemy.dialects.postgresql import JSONB, ARRAY
from sqlalchemy.sql import func
import os
import logging
from datetime import datetime

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Получение параметров подключения из переменных окружения или использование значений по умолчанию
DB_USER = os.environ.get('DB_USER', 'postgres')
DB_PASSWORD = os.environ.get('DB_PASSWORD', 'postgres')
DB_HOST = os.environ.get('DB_HOST', 'localhost')
DB_PORT = os.environ.get('DB_PORT', '5432')
DB_NAME = os.environ.get('DB_NAME', 'ai_bot_db')

# Формирование строки подключения
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# Создание движка SQLAlchemy
engine = create_engine(DATABASE_URL, pool_size=10, max_overflow=20)

# Создание базового класса для моделей
Base = declarative_base()

# Создание сессии
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
db_session = scoped_session(SessionLocal)

def get_db():
    """
    Функция для получения сессии базы данных.
    Используется как зависимость в FastAPI.
    """
    db = db_session()
    try:
        yield db
    finally:
        db.close()

def init_db():
    """
    Инициализация базы данных.
    Создает все таблицы, определенные в моделях.
    """
    try:
        # Создание расширения pgvector, если оно еще не создано
        engine.execute('CREATE EXTENSION IF NOT EXISTS vector;')
        logger.info("Расширение pgvector успешно создано или уже существует")
        
        # Создание всех таблиц
        Base.metadata.create_all(bind=engine)
        logger.info("Все таблицы успешно созданы")
        
        return True
    except Exception as e:
        logger.error(f"Ошибка при инициализации базы данных: {e}")
        return False
