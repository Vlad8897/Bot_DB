"""
Скрипт для инициализации базы данных PostgreSQL с расширением pgvector.
Создает базу данных, устанавливает расширение pgvector и создает необходимые таблицы.
"""

import os
import sys
import logging
import argparse
import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

# Добавление родительской директории в путь для импорта
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.models.base import init_db, Base, engine
from database.utils.vector_db import VectorDBManager

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_database(db_name, db_user, db_password, db_host, db_port):
    """
    Создание базы данных PostgreSQL, если она не существует.
    
    Args:
        db_name: Имя базы данных
        db_user: Имя пользователя
        db_password: Пароль
        db_host: Хост
        db_port: Порт
        
    Returns:
        bool: True, если база данных успешно создана или уже существует, иначе False
    """
    try:
        # Подключение к PostgreSQL
        conn = psycopg2.connect(
            user=db_user,
            password=db_password,
            host=db_host,
            port=db_port,
            database="postgres"  # Подключение к системной базе данных
        )
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = conn.cursor()
        
        # Проверка существования базы данных
        cursor.execute(f"SELECT 1 FROM pg_database WHERE datname = '{db_name}'")
        exists = cursor.fetchone()
        
        if not exists:
            # Создание базы данных
            cursor.execute(f"CREATE DATABASE {db_name}")
            logger.info(f"База данных {db_name} успешно создана")
        else:
            logger.info(f"База данных {db_name} уже существует")
        
        cursor.close()
        conn.close()
        
        # Подключение к созданной базе данных для установки расширения pgvector
        conn = psycopg2.connect(
            user=db_user,
            password=db_password,
            host=db_host,
            port=db_port,
            database=db_name
        )
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = conn.cursor()
        
        # Установка расширения pgvector
        cursor.execute("CREATE EXTENSION IF NOT EXISTS vector")
        logger.info("Расширение pgvector успешно установлено")
        
        cursor.close()
        conn.close()
        
        return True
    except Exception as e:
        logger.error(f"Ошибка при создании базы данных: {e}")
        return False

def initialize_database():
    """
    Инициализация базы данных: создание таблиц и индексов.
    
    Returns:
        bool: True, если база данных успешно инициализирована, иначе False
    """
    try:
        # Получение параметров подключения из переменных окружения или использование значений по умолчанию
        db_user = os.environ.get('DB_USER', 'postgres')
        db_password = os.environ.get('DB_PASSWORD', 'postgres')
        db_host = os.environ.get('DB_HOST', 'localhost')
        db_port = os.environ.get('DB_PORT', '5432')
        db_name = os.environ.get('DB_NAME', 'ai_bot_db')
        
        # Создание базы данных
        if not create_database(db_name, db_user, db_password, db_host, db_port):
            return False
        
        # Создание таблиц
        if not init_db():
            return False
        
        # Создание векторных индексов
        vector_db = VectorDBManager()
        if not vector_db.update_vector_indices():
            return False
        
        logger.info("База данных успешно инициализирована")
        return True
    except Exception as e:
        logger.error(f"Ошибка при инициализации базы данных: {e}")
        return False

def main():
    """
    Основная функция для запуска инициализации базы данных.
    """
    parser = argparse.ArgumentParser(description='Инициализация базы данных PostgreSQL с расширением pgvector')
    parser.add_argument('--reset', action='store_true', help='Сбросить существующую базу данных и создать новую')
    args = parser.parse_args()
    
    if args.reset:
        # Удаление всех таблиц
        Base.metadata.drop_all(engine)
        logger.info("Все таблицы успешно удалены")
    
    # Инициализация базы данных
    if initialize_database():
        logger.info("Инициализация базы данных завершена успешно")
    else:
        logger.error("Не удалось инициализировать базу данных")
        sys.exit(1)

if __name__ == "__main__":
    main()
