'use client';

import { useLocalization } from '@/hooks/useLocalization';
import { Locale } from '@/lib/i18n';

export function LanguageSwitcher() {
  const { locale, setLocale, t } = useLocalization();

  const toggleLanguage = () => {
    setLocale(locale === 'ru' ? 'en' : 'ru');
  };

  return (
    <div className="flex items-center space-x-2">
      <span className="text-sm font-medium">{t('app.language')}:</span>
      <button
        onClick={toggleLanguage}
        className="px-3 py-1 text-sm font-medium rounded-md bg-blue-100 text-blue-700 hover:bg-blue-200 dark:bg-blue-900 dark:text-blue-100 dark:hover:bg-blue-800 transition-colors"
      >
        {locale === 'ru' ? 'English' : 'Русский'}
      </button>
    </div>
  );
}
