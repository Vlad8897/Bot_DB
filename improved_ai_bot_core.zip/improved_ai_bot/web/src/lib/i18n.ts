// Типы для локализации
export type Locale = 'ru' | 'en';

export type Translations = {
  [key: string]: {
    [locale in Locale]: string;
  };
};

// Словарь переводов
export const translations: Translations = {
  // Общие
  'app.title': {
    ru: 'DeepSeek Бот',
    en: 'DeepSeek Bot',
  },
  'app.description': {
    ru: 'Бот на основе DeepSeek для работы с базой данных',
    en: 'DeepSeek-based bot for database interaction',
  },
  'app.language': {
    ru: 'Язык',
    en: 'Language',
  },
  'app.loading': {
    ru: 'Загрузка...',
    en: 'Loading...',
  },
  'app.error': {
    ru: 'Произошла ошибка',
    en: 'An error occurred',
  },
  'app.submit': {
    ru: 'Отправить',
    en: 'Submit',
  },
  'app.cancel': {
    ru: 'Отмена',
    en: 'Cancel',
  },
  'app.save': {
    ru: 'Сохранить',
    en: 'Save',
  },
  'app.delete': {
    ru: 'Удалить',
    en: 'Delete',
  },
  'app.edit': {
    ru: 'Редактировать',
    en: 'Edit',
  },
  'app.back': {
    ru: 'Назад',
    en: 'Back',
  },
  'app.search': {
    ru: 'Поиск',
    en: 'Search',
  },
  
  // Навигация
  'nav.home': {
    ru: 'Главная',
    en: 'Home',
  },
  'nav.query': {
    ru: 'Запрос',
    en: 'Query',
  },
  'nav.documents': {
    ru: 'Документы',
    en: 'Documents',
  },
  'nav.addDocument': {
    ru: 'Добавить документ',
    en: 'Add Document',
  },
  'nav.importData': {
    ru: 'Импорт данных',
    en: 'Import Data',
  },
  'nav.search': {
    ru: 'Поиск',
    en: 'Search',
  },
  'nav.categories': {
    ru: 'Категории',
    en: 'Categories',
  },
  'nav.history': {
    ru: 'История',
    en: 'History',
  },
  
  // Страница запросов
  'query.title': {
    ru: 'Запрос к боту',
    en: 'Bot Query',
  },
  'query.placeholder': {
    ru: 'Введите ваш запрос...',
    en: 'Enter your query...',
  },
  'query.submit': {
    ru: 'Отправить запрос',
    en: 'Submit Query',
  },
  'query.result': {
    ru: 'Результат',
    en: 'Result',
  },
  'query.sources': {
    ru: 'Источники',
    en: 'Sources',
  },
  'query.noSources': {
    ru: 'Нет источников',
    en: 'No sources',
  },
  
  // Страница документов
  'documents.title': {
    ru: 'Документы',
    en: 'Documents',
  },
  'documents.empty': {
    ru: 'Нет документов',
    en: 'No documents',
  },
  'documents.add': {
    ru: 'Добавить документ',
    en: 'Add Document',
  },
  'documents.import': {
    ru: 'Импортировать документы',
    en: 'Import Documents',
  },
  
  // Страница добавления документа
  'addDocument.title': {
    ru: 'Добавление документа',
    en: 'Add Document',
  },
  'addDocument.titleField': {
    ru: 'Заголовок',
    en: 'Title',
  },
  'addDocument.contentField': {
    ru: 'Содержимое',
    en: 'Content',
  },
  'addDocument.metadataField': {
    ru: 'Метаданные (JSON)',
    en: 'Metadata (JSON)',
  },
  'addDocument.sourceTypeField': {
    ru: 'Тип источника',
    en: 'Source Type',
  },
  'addDocument.categoryField': {
    ru: 'Категория',
    en: 'Category',
  },
  'addDocument.success': {
    ru: 'Документ успешно добавлен',
    en: 'Document successfully added',
  },
  
  // Страница поиска
  'search.title': {
    ru: 'Поиск документов',
    en: 'Search Documents',
  },
  'search.placeholder': {
    ru: 'Введите поисковый запрос...',
    en: 'Enter search query...',
  },
  'search.limit': {
    ru: 'Максимальное количество результатов',
    en: 'Maximum number of results',
  },
  'search.noResults': {
    ru: 'По вашему запросу ничего не найдено',
    en: 'No results found for your query',
  },
  
  // Страница категорий
  'categories.title': {
    ru: 'Категории',
    en: 'Categories',
  },
  'categories.empty': {
    ru: 'Нет категорий',
    en: 'No categories',
  },
  'categories.add': {
    ru: 'Добавить категорию',
    en: 'Add Category',
  },
  
  // Страница истории
  'history.title': {
    ru: 'История запросов',
    en: 'Query History',
  },
  'history.empty': {
    ru: 'История запросов пуста',
    en: 'Query history is empty',
  },
  'history.query': {
    ru: 'Запрос',
    en: 'Query',
  },
  'history.response': {
    ru: 'Ответ',
    en: 'Response',
  },
  'history.timestamp': {
    ru: 'Время',
    en: 'Time',
  },
};

// Функция для получения перевода
export function getTranslation(key: string, locale: Locale): string {
  if (!translations[key]) {
    console.warn(`Translation key not found: ${key}`);
    return key;
  }
  
  return translations[key][locale] || key;
}
