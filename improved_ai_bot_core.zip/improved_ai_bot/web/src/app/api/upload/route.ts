import { NextRequest, NextResponse } from 'next/server';
import { writeFile } from 'fs/promises';
import { join } from 'path';
import { getDatabase } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const title = formData.get('title') as string;
    const category = formData.get('category') as string;
    
    if (!file) {
      return NextResponse.json(
        { error: 'Файл не предоставлен' },
        { status: 400 }
      );
    }

    // Сохраняем файл
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const fileName = `${Date.now()}-${file.name}`;
    const path = join(process.cwd(), 'public', 'uploads', fileName);
    await writeFile(path, buffer);

    // Сохраняем информацию о файле в базу данных
    const db = getDatabase();
    await db.createDocument({
      title: title || file.name,
      content: `Аудиофайл: /uploads/${fileName}`,
      metadata: JSON.stringify({
        type: 'audio',
        originalName: file.name,
        size: file.size,
        mimeType: file.type
      }),
      source_type: 'file',
      category_id: category || undefined
    });

    return NextResponse.json({ 
      success: true, 
      fileName, 
      path: `/uploads/${fileName}` 
    });
  } catch (error) {
    console.error('Ошибка при загрузке файла:', error);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    );
  }
}
