DROP TABLE IF EXISTS documents;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS query_history;

-- Таблица категорий
CREATE TABLE categories (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  parent_id INTEGER,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (parent_id) REFERENCES categories (id) ON DELETE SET NULL
);

-- Таблица документов
CREATE TABLE documents (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  meta_data TEXT,
  source_type TEXT NOT NULL,
  category_id INTEGER,
  embedding TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL
);

-- Таблица истории запросов
CREATE TABLE query_history (
  id INTEGER PRIMARY KEY,
  user_id TEXT NOT NULL,
  query TEXT NOT NULL,
  response TEXT NOT NULL,
  documents TEXT,
  timestamp TEXT NOT NULL
);

-- Вставка тестовых данных для категорий
INSERT INTO categories (name, parent_id, created_at, updated_at) VALUES
('Общая информация', NULL, datetime('now'), datetime('now')),
('Техническая документация', NULL, datetime('now'), datetime('now')),
('Руководства пользователя', NULL, datetime('now'), datetime('now')),
('API документация', 2, datetime('now'), datetime('now')),
('Инструкции по установке', 2, datetime('now'), datetime('now'));

-- Вставка тестовых данных для документов
INSERT INTO documents (title, content, meta_data, source_type, category_id, created_at, updated_at) VALUES
('Введение в DeepSeek', 'DeepSeek - это мощный инструмент для работы с базами данных, который использует искусственный интеллект для обработки запросов на естественном языке.', '{"author": "Admin", "tags": ["introduction", "overview"]}', 'manual', 1, datetime('now'), datetime('now')),
('Установка DeepSeek на Windows', 'Подробная инструкция по установке DeepSeek на операционную систему Windows. Шаг 1: Скачайте установщик с официального сайта...', '{"author": "Admin", "os": "Windows", "version": "1.0"}', 'manual', 5, datetime('now'), datetime('now')),
('Установка DeepSeek на Linux', 'Подробная инструкция по установке DeepSeek на операционную систему Linux. Шаг 1: Используйте пакетный менеджер для установки...', '{"author": "Admin", "os": "Linux", "version": "1.0"}', 'manual', 5, datetime('now'), datetime('now')),
('API Reference', 'Документация по API DeepSeek. Включает описание всех доступных эндпоинтов и параметров.', '{"author": "Developer", "version": "1.0"}', 'manual', 4, datetime('now'), datetime('now')),
('Руководство по использованию', 'Подробное руководство по использованию DeepSeek для работы с базами данных. Включает примеры запросов и ответов.', '{"author": "Admin", "tags": ["usage", "examples"]}', 'manual', 3, datetime('now'), datetime('now'));

-- Вставка тестовых данных для истории запросов
INSERT INTO query_history (user_id, query, response, documents, timestamp) VALUES
('default-user', 'Как установить DeepSeek?', 'Для установки DeepSeek следуйте инструкциям в документации по установке для вашей операционной системы.', '[2, 3]', datetime('now')),
('default-user', 'Что такое DeepSeek?', 'DeepSeek - это мощный инструмент для работы с базами данных, который использует искусственный интеллект для обработки запросов на естественном языке.', '[1]', datetime('now', '-1 day')),
('default-user', 'Как использовать API?', 'API DeepSeek предоставляет различные эндпоинты для взаимодействия с базой данных. Подробную информацию можно найти в API Reference.', '[4]', datetime('now', '-2 days'));
