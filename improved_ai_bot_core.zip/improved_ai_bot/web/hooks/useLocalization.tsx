'use client';

import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Locale, getTranslation } from '@/lib/i18n';

// Тип для контекста локализации
interface LocalizationContextType {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (key: string) => string;
}

// Создание контекста с начальными значениями
const LocalizationContext = createContext<LocalizationContextType>({
  locale: 'ru',
  setLocale: () => {},
  t: (key: string) => key,
});

// Провайдер локализации
export function LocalizationProvider({ children }: { children: ReactNode }) {
  const [locale, setLocale] = useState<Locale>('ru');
  const [translations, setTranslations] = useState<Record<string, string>>({});

  // Загрузка переводов при изменении локали
  useEffect(() => {
    const loadTranslations = async () => {
      const trans = await getTranslation(locale);
      setTranslations(trans);
    };
    
    loadTranslations();
    
    // Сохраняем выбранный язык в localStorage
    localStorage.setItem('locale', locale);
  }, [locale]);

  // Функция для получения перевода по ключу
  const t = (key: string): string => {
    return translations[key] || key;
  };

  return (
    <LocalizationContext.Provider value={{ locale, setLocale, t }}>
      {children}
    </LocalizationContext.Provider>
  );
}

// Хук для использования локализации в компонентах
export function useLocalization() {
  return useContext(LocalizationContext);
}
