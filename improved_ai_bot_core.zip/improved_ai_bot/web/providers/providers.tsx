import { LocalizationProvider } from '@/hooks/useLocalization';
import { ReactNode } from 'react';

// Компонент для обертывания приложения провайдерами
export function Providers({ children }: { children: ReactNode }) {
  return (
    <LocalizationProvider>
      {children}
    </LocalizationProvider>
  );
}
