import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    if (!body.title || !body.content) {
      return NextResponse.json(
        { error: 'Необходимо указать заголовок и содержимое документа' },
        { status: 400 }
      );
    }
    
    const db = getDatabase();
    const documentId = await db.createDocument({
      title: body.title,
      content: body.content,
      meta_data: body.metadata || {},
      source_type: body.source_type || 'manual',
      category_id: body.category || undefined
    });
    
    return NextResponse.json({ id: documentId, success: true });
  } catch (error) {
    console.error('Ошибка при добавлении документа:', error);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    );
  }
}
