import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const categoryId = parseInt(params.id);
    
    if (isNaN(categoryId)) {
      return NextResponse.json(
        { error: 'Некорректный ID категории' },
        { status: 400 }
      );
    }
    
    const db = getDatabase();
    const documents = await db.getDocumentsByCategory(categoryId);
    
    return NextResponse.json(documents);
  } catch (error) {
    console.error('Ошибка при получении документов категории:', error);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    );
  }
}
