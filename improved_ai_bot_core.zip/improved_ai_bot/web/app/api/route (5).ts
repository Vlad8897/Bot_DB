import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    // В реальном приложении здесь должна быть аутентификация
    // и получение user_id из сессии пользователя
    const userId = 'default-user';
    const limit = 100;
    
    const db = getDatabase();
    const history = await db.getQueryHistory(userId, limit);
    
    return NextResponse.json(history);
  } catch (error) {
    console.error('Ошибка при получении истории запросов:', error);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    );
  }
}
