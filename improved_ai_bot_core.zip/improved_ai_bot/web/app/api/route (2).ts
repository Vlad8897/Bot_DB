import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const documentId = parseInt(params.id);
    
    if (isNaN(documentId)) {
      return NextResponse.json(
        { error: 'Некорректный ID документа' },
        { status: 400 }
      );
    }
    
    const db = getDatabase();
    const document = await db.getDocumentById(documentId);
    
    if (!document) {
      return NextResponse.json(
        { error: 'Документ не найден' },
        { status: 404 }
      );
    }
    
    // Если у документа есть категория, получаем информацию о ней
    if (document.category_id) {
      const category = await db.getCategoryById(document.category_id);
      if (category) {
        return NextResponse.json({
          ...document,
          category
        });
      }
    }
    
    return NextResponse.json(document);
  } catch (error) {
    console.error('Ошибка при получении документа:', error);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    );
  }
}
