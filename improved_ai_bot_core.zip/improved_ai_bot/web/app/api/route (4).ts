import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const query = searchParams.get('query');
    const limit = parseInt(searchParams.get('limit') || '10');
    
    if (!query) {
      return NextResponse.json(
        { error: 'Необходимо указать поисковый запрос' },
        { status: 400 }
      );
    }
    
    const db = getDatabase();
    const results = await db.searchDocuments(query, limit);
    
    return NextResponse.json(results);
  } catch (error) {
    console.error('Ошибка при поиске документов:', error);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    );
  }
}
