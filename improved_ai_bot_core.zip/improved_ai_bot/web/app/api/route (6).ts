import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    if (!body.query) {
      return NextResponse.json(
        { error: 'Необходимо указать текст запроса' },
        { status: 400 }
      );
    }
    
    // Здесь должна быть интеграция с DeepSeek API
    // Для демонстрации используем заглушку
    const response = `Ответ на запрос: ${body.query}`;
    
    // В реальном приложении здесь должна быть аутентификация
    // и получение user_id из сессии пользователя
    const userId = 'default-user';
    
    // Сохраняем запрос в историю
    const db = getDatabase();
    await db.createQueryHistory({
      user_id: userId,
      query: body.query,
      response: response,
      documents: body.documents || []
    });
    
    return NextResponse.json({ response });
  } catch (error) {
    console.error('Ошибка при обработке запроса:', error);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    );
  }
}
