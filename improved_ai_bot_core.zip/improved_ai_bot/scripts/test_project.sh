#!/bin/bash

# Скрипт для тестирования полной сборки проекта AI бота
# Проверяет работоспособность всех компонентов и их взаимодействие

# Цвета для вывода
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Функция для вывода сообщений
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

# Функция для вывода успешных сообщений
success() {
    echo -e "${GREEN}[УСПЕХ]${NC} $1"
}

# Функция для вывода предупреждений
warning() {
    echo -e "${YELLOW}[ПРЕДУПРЕЖДЕНИЕ]${NC} $1"
}

# Функция для вывода ошибок
error() {
    echo -e "${RED}[ОШИБКА]${NC} $1"
}

# Функция для проверки наличия зависимостей
check_dependencies() {
    log "Проверка наличия необходимых зависимостей..."
    
    # Список необходимых Python-пакетов
    python_packages=(
        "flask" "sqlalchemy" "psycopg2-binary" "numpy" "torch" "transformers" 
        "sentence-transformers" "librosa" "soundfile" "gtts" "requests"
    )
    
    # Список необходимых системных пакетов
    system_packages=(
        "postgresql" "postgresql-contrib" "python3-dev" "libpq-dev" "ffmpeg" "libsndfile1"
    )
    
    # Проверка Python-пакетов
    missing_python=()
    for package in "${python_packages[@]}"; do
        if ! pip3 list | grep -q "$package"; then
            missing_python+=("$package")
        fi
    done
    
    # Проверка системных пакетов
    missing_system=()
    for package in "${system_packages[@]}"; do
        if ! dpkg -l | grep -q "$package"; then
            missing_system+=("$package")
        fi
    done
    
    # Вывод результатов
    if [ ${#missing_python[@]} -eq 0 ] && [ ${#missing_system[@]} -eq 0 ]; then
        success "Все необходимые зависимости установлены"
        return 0
    else
        warning "Отсутствуют следующие зависимости:"
        
        if [ ${#missing_python[@]} -gt 0 ]; then
            echo "Python-пакеты: ${missing_python[*]}"
            echo "Для установки выполните: pip3 install ${missing_python[*]}"
        fi
        
        if [ ${#missing_system[@]} -gt 0 ]; then
            echo "Системные пакеты: ${missing_system[*]}"
            echo "Для установки выполните: sudo apt-get install ${missing_system[*]}"
        fi
        
        return 1
    fi
}

# Функция для проверки структуры проекта
check_project_structure() {
    log "Проверка структуры проекта..."
    
    # Список необходимых директорий
    directories=(
        "bot" "database" "web-app" "scripts" "docs"
    )
    
    # Проверка наличия директорий
    missing_dirs=()
    for dir in "${directories[@]}"; do
        if [ ! -d "$dir" ]; then
            missing_dirs+=("$dir")
        fi
    done
    
    # Список ключевых файлов
    key_files=(
        "bot/bot_core.py" "bot/db_manager.py" "bot/audio_processor.py" "bot/vector_db_manager.py"
        "database/postgresql_setup.py" "database/models.py" "database/db_setup.py"
        "web-app/package.json" "web-app/next.config.js"
        "docs/documentation.md" "docs/report.md"
    )
    
    # Проверка наличия ключевых файлов
    missing_files=()
    for file in "${key_files[@]}"; do
        if [ ! -f "$file" ]; then
            missing_files+=("$file")
        fi
    done
    
    # Вывод результатов
    if [ ${#missing_dirs[@]} -eq 0 ] && [ ${#missing_files[@]} -eq 0 ]; then
        success "Структура проекта корректна"
        return 0
    else
        error "Проблемы со структурой проекта:"
        
        if [ ${#missing_dirs[@]} -gt 0 ]; then
            echo "Отсутствуют директории: ${missing_dirs[*]}"
        fi
        
        if [ ${#missing_files[@]} -gt 0 ]; then
            echo "Отсутствуют ключевые файлы: ${missing_files[*]}"
        fi
        
        return 1
    fi
}

# Функция для проверки синтаксиса Python-файлов
check_python_syntax() {
    log "Проверка синтаксиса Python-файлов..."
    
    # Поиск всех Python-файлов
    python_files=$(find . -name "*.py")
    
    # Проверка синтаксиса
    syntax_errors=()
    for file in $python_files; do
        if ! python3 -m py_compile "$file" 2>/dev/null; then
            syntax_errors+=("$file")
        fi
    done
    
    # Вывод результатов
    if [ ${#syntax_errors[@]} -eq 0 ]; then
        success "Синтаксис всех Python-файлов корректен"
        return 0
    else
        error "Синтаксические ошибки в следующих файлах:"
        for file in "${syntax_errors[@]}"; do
            echo "$file"
            python3 -m py_compile "$file" 2>&1 | head -n 5
            echo "---"
        done
        return 1
    fi
}

# Функция для проверки package.json
check_package_json() {
    log "Проверка package.json..."
    
    if [ ! -f "web-app/package.json" ]; then
        error "Файл web-app/package.json не найден"
        return 1
    fi
    
    # Проверка валидности JSON
    if ! jq . "web-app/package.json" >/dev/null 2>&1; then
        error "Файл web-app/package.json содержит невалидный JSON"
        return 1
    fi
    
    # Проверка наличия необходимых полей
    required_fields=("name" "version" "scripts" "dependencies")
    missing_fields=()
    
    for field in "${required_fields[@]}"; do
        if ! jq -e ".$field" "web-app/package.json" >/dev/null 2>&1; then
            missing_fields+=("$field")
        fi
    done
    
    # Проверка наличия скрипта запуска
    if ! jq -e '.scripts.dev' "web-app/package.json" >/dev/null 2>&1 && ! jq -e '.scripts.start' "web-app/package.json" >/dev/null 2>&1; then
        missing_fields+=("scripts.dev или scripts.start")
    fi
    
    # Вывод результатов
    if [ ${#missing_fields[@]} -eq 0 ]; then
        success "Файл package.json корректен"
        return 0
    else
        error "В файле package.json отсутствуют следующие поля: ${missing_fields[*]}"
        return 1
    fi
}

# Функция для проверки базы данных PostgreSQL
check_postgresql() {
    log "Проверка настройки PostgreSQL..."
    
    # Проверка установки PostgreSQL
    if ! command -v psql &>/dev/null; then
        error "PostgreSQL не установлен"
        return 1
    fi
    
    # Проверка запуска сервера PostgreSQL
    if ! pg_isready &>/dev/null; then
        warning "Сервер PostgreSQL не запущен"
        echo "Для запуска выполните: sudo service postgresql start"
        return 1
    fi
    
    # Проверка наличия расширения pgvector
    if ! sudo -u postgres psql -c "SELECT * FROM pg_available_extensions WHERE name = 'vector'" | grep -q "vector"; then
        warning "Расширение pgvector не установлено"
        echo "Для установки выполните: sudo apt-get install postgresql-14-pgvector (или соответствующую версию)"
        return 1
    fi
    
    success "PostgreSQL настроен корректно"
    return 0
}

# Функция для проверки интеграции компонентов
check_integration() {
    log "Проверка интеграции компонентов..."
    
    # Проверка импортов в Python-файлах
    import_errors=()
    
    # Проверка импорта моделей базы данных в bot_core.py
    if ! grep -q "from database" "bot/bot_core.py" && ! grep -q "import.*database" "bot/bot_core.py"; then
        import_errors+=("bot/bot_core.py не импортирует модули из database")
    fi
    
    # Проверка импорта обработчика аудио в vector_db_manager.py
    if ! grep -q "from bot.audio_processor" "bot/vector_db_manager.py" && ! grep -q "import.*audio_processor" "bot/vector_db_manager.py"; then
        import_errors+=("bot/vector_db_manager.py не импортирует модуль audio_processor")
    fi
    
    # Проверка API-маршрутов в веб-приложении
    api_routes=(
        "web-app/src/app/api/chat/route.ts"
        "web-app/src/app/api/upload/route.ts"
        "web-app/src/app/api/audio/route.ts"
        "web-app/src/app/api/documents/route.ts"
    )
    
    missing_routes=()
    for route in "${api_routes[@]}"; do
        if [ ! -f "$route" ]; then
            missing_routes+=("$route")
        fi
    done
    
    # Вывод результатов
    if [ ${#import_errors[@]} -eq 0 ] && [ ${#missing_routes[@]} -eq 0 ]; then
        success "Интеграция компонентов корректна"
        return 0
    else
        warning "Проблемы с интеграцией компонентов:"
        
        if [ ${#import_errors[@]} -gt 0 ]; then
            echo "Ошибки импорта:"
            for error in "${import_errors[@]}"; do
                echo "- $error"
            done
        fi
        
        if [ ${#missing_routes[@]} -gt 0 ]; then
            echo "Отсутствуют API-маршруты:"
            for route in "${missing_routes[@]}"; do
                echo "- $route"
            done
        fi
        
        return 1
    fi
}

# Функция для создания тестового ZIP-архива
create_test_zip() {
    log "Создание тестового ZIP-архива..."
    
    # Создание архива
    zip -r improved_ai_bot.zip . -x "*.git*" "*.zip" "*.pyc" "__pycache__/*" "node_modules/*" ".next/*" >/dev/null
    
    if [ $? -eq 0 ]; then
        success "Тестовый ZIP-архив успешно создан: improved_ai_bot.zip"
        return 0
    else
        error "Ошибка при создании тестового ZIP-архива"
        return 1
    fi
}

# Основная функция тестирования
main() {
    log "Начало тестирования полной сборки проекта AI бота"
    echo "----------------------------------------------------"
    
    # Массив для хранения результатов тестов
    test_results=()
    
    # Проверка зависимостей
    if check_dependencies; then
        test_results+=("Зависимости: ✅")
    else
        test_results+=("Зависимости: ❌")
    fi
    echo "----------------------------------------------------"
    
    # Проверка структуры проекта
    if check_project_structure; then
        test_results+=("Структура проекта: ✅")
    else
        test_results+=("Структура проекта: ❌")
    fi
    echo "----------------------------------------------------"
    
    # Проверка синтаксиса Python-файлов
    if check_python_syntax; then
        test_results+=("Синтаксис Python: ✅")
    else
        test_results+=("Синтаксис Python: ❌")
    fi
    echo "----------------------------------------------------"
    
    # Проверка package.json
    if check_package_json; then
        test_results+=("package.json: ✅")
    else
        test_results+=("package.json: ❌")
    fi
    echo "----------------------------------------------------"
    
    # Проверка PostgreSQL
    if check_postgresql; then
        test_results+=("PostgreSQL: ✅")
    else
        test_results+=("PostgreSQL: ❌")
    fi
    echo "----------------------------------------------------"
    
    # Проверка интеграции компонентов
    if check_integration; then
        test_results+=("Интеграция компонентов: ✅")
    else
        test_results+=("Интеграция компонентов: ❌")
    fi
    echo "----------------------------------------------------"
    
    # Создание тестового ZIP-архива
    if create_test_zip; then
        test_results+=("Создание ZIP-архива: ✅")
    else
        test_results+=("Создание ZIP-архива: ❌")
    fi
    echo "----------------------------------------------------"
    
    # Вывод общих результатов
    log "Результаты тестирования:"
    for result in "${test_results[@]}"; do
        echo "$result"
    done
    
    # Подсчет успешных и неуспешных тестов
    success_count=$(echo "${test_results[@]}" | grep -o "✅" | wc -l)
    total_count=${#test_results[@]}
    
    echo "----------------------------------------------------"
    if [ $success_count -eq $total_count ]; then
        success "Все тесты пройдены успешно! Проект готов к использованию."
    else
        warning "Пройдено $success_count из $total_count тестов. Необходимо исправить ошибки перед использованием."
    fi
    
    log "Тестирование завершено"
}

# Запуск основной функции
main
