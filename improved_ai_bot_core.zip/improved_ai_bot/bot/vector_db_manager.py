#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Скрипт для интеграции бота с векторной базой данных и обработкой аудио.
Обновляет существующий функционал бота для работы с PostgreSQL и векторными представлениями.
"""

import os
import sys
import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database.postgresql_setup import Document, DocumentChunk, UserQuery, QueryDocumentRelevance, DATABASE_URL
from bot.audio_processor import AudioProcessor
import numpy as np
from datetime import datetime
import json

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

class VectorDBManager:
    """Класс для управления векторной базой данных"""
    
    def __init__(self):
        """Инициализация подключения к базе данных"""
        try:
            # Подключение к базе данных
            self.engine = create_engine(DATABASE_URL)
            self.Session = sessionmaker(bind=self.engine)
            
            # Инициализация обработчика аудио
            self.audio_processor = AudioProcessor()
            
            logger.info("Менеджер векторной базы данных успешно инициализирован")
            
        except Exception as e:
            logger.error(f"Ошибка при инициализации менеджера векторной базы данных: {e}")
            raise
    
    def add_document(self, title, content, category=None, file_path=None, file_type=None, metadata=None):
        """
        Добавление документа в базу данных
        
        Args:
            title (str): Заголовок документа
            content (str): Содержимое документа
            category (str, optional): Категория документа
            file_path (str, optional): Путь к файлу документа
            file_type (str, optional): Тип файла документа
            metadata (dict, optional): Метаданные документа
            
        Returns:
            int: ID добавленного документа
        """
        try:
            # Векторизация содержимого документа
            content_vector = self.audio_processor.get_text_embedding(content)
            
            # Создание сессии
            session = self.Session()
            
            # Создание документа
            document = Document(
                title=title,
                content=content,
                content_vector=content_vector,
                file_path=file_path,
                file_type=file_type,
                category=category,
                metadata=metadata or {}
            )
            
            session.add(document)
            session.commit()
            
            document_id = document.id
            
            # Разделение документа на фрагменты для более эффективного поиска
            chunks = self._split_text_into_chunks(content)
            
            for i, chunk in enumerate(chunks):
                chunk_vector = self.audio_processor.get_text_embedding(chunk)
                
                document_chunk = DocumentChunk(
                    document_id=document_id,
                    content=chunk,
                    content_vector=chunk_vector,
                    chunk_index=i,
                    metadata={"position": i, "total_chunks": len(chunks)}
                )
                
                session.add(document_chunk)
            
            session.commit()
            session.close()
            
            logger.info(f"Документ успешно добавлен в базу данных: {title}")
            return document_id
            
        except Exception as e:
            logger.error(f"Ошибка при добавлении документа в базу данных: {e}")
            raise
    
    def _split_text_into_chunks(self, text, chunk_size=1000, overlap=200):
        """
        Разделение текста на перекрывающиеся фрагменты
        
        Args:
            text (str): Текст для разделения
            chunk_size (int, optional): Размер фрагмента в символах
            overlap (int, optional): Размер перекрытия между фрагментами
            
        Returns:
            list: Список фрагментов текста
        """
        if len(text) <= chunk_size:
            return [text]
        
        chunks = []
        start = 0
        
        while start < len(text):
            # Определение конца фрагмента
            end = min(start + chunk_size, len(text))
            
            # Поиск ближайшего конца предложения или абзаца
            if end < len(text):
                # Поиск конца абзаца
                paragraph_end = text.rfind('\n\n', start, end)
                if paragraph_end > start + chunk_size // 2:
                    end = paragraph_end + 2
                else:
                    # Поиск конца предложения
                    sentence_end = max(
                        text.rfind('. ', start, end),
                        text.rfind('! ', start, end),
                        text.rfind('? ', start, end)
                    )
                    if sentence_end > start + chunk_size // 2:
                        end = sentence_end + 2
            
            # Добавление фрагмента
            chunks.append(text[start:end])
            
            # Переход к следующему фрагменту с учетом перекрытия
            start = end - overlap
        
        return chunks
    
    def search_documents(self, query_text, limit=5):
        """
        Поиск документов по текстовому запросу
        
        Args:
            query_text (str): Текст запроса
            limit (int, optional): Максимальное количество результатов
            
        Returns:
            list: Список найденных документов с оценкой релевантности
        """
        try:
            # Векторизация запроса
            query_vector = self.audio_processor.get_text_embedding(query_text)
            
            # Создание сессии
            session = self.Session()
            
            # SQL-запрос для векторного поиска по фрагментам документов
            query = """
            WITH ranked_chunks AS (
                SELECT 
                    dc.document_id,
                    dc.content,
                    1 - (dc.content_vector <=> :query_vector) as similarity,
                    ROW_NUMBER() OVER (PARTITION BY dc.document_id ORDER BY 1 - (dc.content_vector <=> :query_vector) DESC) as rank
                FROM document_chunks dc
            )
            SELECT 
                d.id,
                d.title,
                d.category,
                rc.content as excerpt,
                rc.similarity
            FROM ranked_chunks rc
            JOIN documents d ON rc.document_id = d.id
            WHERE rc.rank = 1
            ORDER BY rc.similarity DESC
            LIMIT :limit
            """
            
            result = session.execute(
                query,
                {"query_vector": query_vector, "limit": limit}
            )
            
            # Форматирование результатов
            documents = []
            for row in result:
                documents.append({
                    "id": row[0],
                    "title": row[1],
                    "category": row[2],
                    "excerpt": row[3],
                    "similarity": float(row[4])
                })
            
            # Сохранение запроса пользователя
            user_query = UserQuery(
                query_text=query_text,
                query_vector=query_vector
            )
            
            session.add(user_query)
            session.commit()
            
            query_id = user_query.id
            
            # Сохранение связей с релевантными документами
            for doc in documents:
                relevance = QueryDocumentRelevance(
                    query_id=query_id,
                    document_id=doc["id"],
                    relevance_score=doc["similarity"]
                )
                
                session.add(relevance)
            
            session.commit()
            session.close()
            
            return documents
            
        except Exception as e:
            logger.error(f"Ошибка при поиске документов: {e}")
            raise
    
    def search_documents_by_audio(self, audio_path, limit=5):
        """
        Поиск документов по аудиозапросу
        
        Args:
            audio_path (str): Путь к аудиофайлу
            limit (int, optional): Максимальное количество результатов
            
        Returns:
            dict: Результаты поиска и транскрипция аудио
        """
        try:
            # Транскрипция аудио
            transcription_result = self.audio_processor.transcribe_audio(audio_path)
            transcription_text = transcription_result["text"]
            
            # Сохранение аудиофайла в базе данных
            audio_id = self.audio_processor.process_and_save_audio(
                audio_path,
                metadata={"query": True, "transcription": transcription_text}
            )
            
            # Поиск документов по транскрипции
            documents = self.search_documents(transcription_text, limit)
            
            # Обновление запроса с ID аудиофайла
            session = self.Session()
            
            query = session.query(UserQuery).order_by(UserQuery.id.desc()).first()
            if query:
                query.query_audio_id = audio_id
                session.commit()
            
            session.close()
            
            return {
                "transcription": transcription_text,
                "documents": documents
            }
            
        except Exception as e:
            logger.error(f"Ошибка при поиске документов по аудио: {e}")
            raise
    
    def get_user_query_history(self, limit=10):
        """
        Получение истории запросов пользователей
        
        Args:
            limit (int, optional): Максимальное количество результатов
            
        Returns:
            list: История запросов пользователей
        """
        try:
            # Создание сессии
            session = self.Session()
            
            # SQL-запрос для получения истории запросов
            query = """
            SELECT 
                uq.id,
                uq.query_text,
                uq.response_text,
                uq.created_at,
                af.transcription,
                array_agg(qdr.document_id) as document_ids
            FROM user_queries uq
            LEFT JOIN audio_files af ON uq.query_audio_id = af.id
            LEFT JOIN query_document_relevance qdr ON uq.id = qdr.query_id
            GROUP BY uq.id, uq.query_text, uq.response_text, uq.created_at, af.transcription
            ORDER BY uq.created_at DESC
            LIMIT :limit
            """
            
            result = session.execute(query, {"limit": limit})
            
            # Форматирование результатов
            history = []
            for row in result:
                history.append({
                    "id": row[0],
                    "query_text": row[1],
                    "response_text": row[2],
                    "created_at": row[3].isoformat() if row[3] else None,
                    "transcription": row[4],
                    "document_ids": row[5] if row[5] and row[5][0] is not None else []
                })
            
            session.close()
            
            return history
            
        except Exception as e:
            logger.error(f"Ошибка при получении истории запросов: {e}")
            raise

def main():
    """Тестирование функциональности векторной базы данных"""
    try:
        # Создание экземпляра менеджера векторной базы данных
        db_manager = VectorDBManager()
        
        # Добавление тестовых документов
        doc1_id = db_manager.add_document(
            title="Введение в векторные базы данных",
            content="""
            Векторные базы данных - это специализированные системы управления базами данных, 
            оптимизированные для хранения и поиска векторных представлений данных. 
            Они особенно полезны в приложениях машинного обучения и искусственного интеллекта, 
            где данные часто представлены в виде многомерных векторов.
            
            Основные преимущества векторных баз данных:
            1. Эффективный поиск по сходству
            2. Масштабируемость для больших объемов данных
            3. Оптимизация для работы с векторными представлениями
            
            PostgreSQL с расширением pgvector - одно из популярных решений для создания 
            векторных баз данных, которое сочетает в себе надежность реляционной СУБД 
            и возможности векторного поиска.
            """,
            category="Технологии",
            metadata={"keywords": ["базы данных", "векторы", "PostgreSQL", "pgvector"]}
        )
        
        doc2_id = db_manager.add_document(
            title="Обработка аудио с помощью модели Whisper",
            content="""
            Whisper - это модель автоматического распознавания речи (ASR), разработанная OpenAI. 
            Она позволяет преобразовывать аудиозаписи в текст с высокой точностью и поддерживает 
            множество языков.
            
            Основные возможности Whisper:
            1. Транскрипция аудио на более чем 90 языках
            2. Перевод речи на английский язык
            3. Идентификация языка аудиозаписи
            4. Временные метки для слов и предложений
            
            Модель доступна в нескольких размерах, от tiny до large, что позволяет выбрать 
            оптимальный баланс между скоростью и точностью в зависимости от требований приложения.
            """,
            category="Искусственный интеллект",
            metadata={"keywords": ["ASR", "Whisper", "OpenAI", "транскрипция"]}
        )
        
        # Поиск документов по запросу
        query = "векторный поиск в PostgreSQL"
        results = db_manager.search_documents(query)
        
        logger.info(f"Результаты поиска по запросу '{query}':")
        for doc in results:
            logger.info(f"ID: {doc['id']}, Заголовок: {doc['title']}, Сходство: {doc['similarity']:.4f}")
            logger.info(f"Фрагмент: {doc['excerpt'][:100]}...")
        
        # Получение истории запросов
        history = db_manager.get_user_query_history()
        
        logger.info("История запросов:")
        for item in history:
            logger.info(f"ID: {item['id']}, Запрос: {item['query_text']}")
            logger.info(f"Время: {item['created_at']}, Документы: {item['document_ids']}")
        
        logger.info("Тестирование векторной базы данных успешно завершено")
        
    except Exception as e:
        logger.error(f"Ошибка при тестировании векторной базы данных: {e}")

if __name__ == "__main__":
    main()
