#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Модуль для обработки аудиофайлов и преобразования их в текст.
Включает функции для транскрипции аудио и сохранения результатов в векторной базе данных.
"""

import os
import sys
import logging
import numpy as np
import torch
from transformers import AutoModelForSpeechSeq2Seq, AutoProcessor, pipeline
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database.postgresql_setup import AudioFile, DATABASE_URL
import librosa
import soundfile as sf
from datetime import datetime
import json

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# Параметры для модели транскрипции
MODEL_ID = "openai/whisper-large-v3"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
COMPUTE_TYPE = "float16" if torch.cuda.is_available() else "float32"

# Параметры для модели векторизации
EMBEDDING_MODEL_ID = "sentence-transformers/all-MiniLM-L6-v2"

class AudioProcessor:
    """Класс для обработки аудиофайлов и их транскрипции"""
    
    def __init__(self):
        """Инициализация моделей для обработки аудио"""
        try:
            # Загрузка модели и процессора для транскрипции
            self.model = AutoModelForSpeechSeq2Seq.from_pretrained(
                MODEL_ID, torch_dtype=torch.float16 if DEVICE == "cuda" else torch.float32
            )
            self.model.to(DEVICE)
            
            self.processor = AutoProcessor.from_pretrained(MODEL_ID)
            
            # Создание пайплайна для автоматической транскрипции
            self.transcriber = pipeline(
                "automatic-speech-recognition",
                model=self.model,
                tokenizer=self.processor.tokenizer,
                feature_extractor=self.processor.feature_extractor,
                max_new_tokens=128,
                chunk_length_s=30,
                batch_size=16,
                return_timestamps=True,
                torch_dtype=torch.float16 if DEVICE == "cuda" else torch.float32,
                device=DEVICE,
            )
            
            # Загрузка модели для векторизации текста
            from sentence_transformers import SentenceTransformer
            self.embedding_model = SentenceTransformer(EMBEDDING_MODEL_ID)
            
            # Подключение к базе данных
            self.engine = create_engine(DATABASE_URL)
            self.Session = sessionmaker(bind=self.engine)
            
            logger.info("Модели для обработки аудио успешно загружены")
            
        except Exception as e:
            logger.error(f"Ошибка при инициализации моделей для обработки аудио: {e}")
            raise
    
    def transcribe_audio(self, audio_path):
        """
        Транскрибирование аудиофайла в текст
        
        Args:
            audio_path (str): Путь к аудиофайлу
            
        Returns:
            dict: Результат транскрипции с текстом и временными метками
        """
        try:
            # Проверка существования файла
            if not os.path.exists(audio_path):
                raise FileNotFoundError(f"Аудиофайл не найден: {audio_path}")
            
            # Загрузка аудиофайла
            audio, sr = librosa.load(audio_path, sr=16000, mono=True)
            
            # Транскрипция аудио
            result = self.transcriber(audio)
            
            logger.info(f"Аудиофайл успешно транскрибирован: {audio_path}")
            return result
            
        except Exception as e:
            logger.error(f"Ошибка при транскрибировании аудиофайла: {e}")
            raise
    
    def get_text_embedding(self, text):
        """
        Получение векторного представления текста
        
        Args:
            text (str): Текст для векторизации
            
        Returns:
            numpy.ndarray: Векторное представление текста
        """
        try:
            # Векторизация текста
            embedding = self.embedding_model.encode(text)
            return embedding.tolist()
            
        except Exception as e:
            logger.error(f"Ошибка при векторизации текста: {e}")
            raise
    
    def process_and_save_audio(self, audio_path, metadata=None):
        """
        Обработка аудиофайла и сохранение результатов в базе данных
        
        Args:
            audio_path (str): Путь к аудиофайлу
            metadata (dict, optional): Метаданные аудиофайла
            
        Returns:
            int: ID сохраненного аудиофайла в базе данных
        """
        try:
            # Получение имени файла
            file_name = os.path.basename(audio_path)
            
            # Получение длительности аудио
            audio, sr = librosa.load(audio_path, sr=None)
            duration = librosa.get_duration(y=audio, sr=sr)
            
            # Транскрипция аудио
            transcription_result = self.transcribe_audio(audio_path)
            transcription_text = transcription_result["text"]
            
            # Векторизация транскрипции
            transcription_vector = self.get_text_embedding(transcription_text)
            
            # Сохранение в базе данных
            session = self.Session()
            
            # Создание записи аудиофайла
            audio_file = AudioFile(
                file_name=file_name,
                file_path=audio_path,
                transcription=transcription_text,
                transcription_vector=transcription_vector,
                duration=duration,
                metadata=metadata or {}
            )
            
            session.add(audio_file)
            session.commit()
            
            audio_id = audio_file.id
            
            session.close()
            
            logger.info(f"Аудиофайл успешно обработан и сохранен в базе данных: {file_name}")
            return audio_id
            
        except Exception as e:
            logger.error(f"Ошибка при обработке и сохранении аудиофайла: {e}")
            raise
    
    def search_similar_audio(self, query_text, limit=5):
        """
        Поиск аудиофайлов с похожей транскрипцией
        
        Args:
            query_text (str): Текст запроса
            limit (int, optional): Максимальное количество результатов
            
        Returns:
            list: Список похожих аудиофайлов с оценкой релевантности
        """
        try:
            # Векторизация запроса
            query_vector = self.get_text_embedding(query_text)
            
            # Поиск похожих аудиофайлов
            session = self.Session()
            
            # SQL-запрос для векторного поиска
            query = """
            SELECT id, file_name, transcription, 
                   1 - (transcription_vector <=> :query_vector) as similarity
            FROM audio_files
            ORDER BY similarity DESC
            LIMIT :limit
            """
            
            result = session.execute(
                query,
                {"query_vector": query_vector, "limit": limit}
            )
            
            # Форматирование результатов
            similar_audio = []
            for row in result:
                similar_audio.append({
                    "id": row[0],
                    "file_name": row[1],
                    "transcription": row[2],
                    "similarity": float(row[3])
                })
            
            session.close()
            
            return similar_audio
            
        except Exception as e:
            logger.error(f"Ошибка при поиске похожих аудиофайлов: {e}")
            raise

def main():
    """Тестирование функциональности обработки аудио"""
    try:
        # Создание экземпляра обработчика аудио
        audio_processor = AudioProcessor()
        
        # Проверка наличия тестового аудиофайла
        test_audio_path = "test_audio.wav"
        if not os.path.exists(test_audio_path):
            # Создание тестового аудиофайла с помощью синтеза речи
            from gtts import gTTS
            
            test_text = "Это тестовый аудиофайл для проверки функциональности обработки аудио."
            tts = gTTS(text=test_text, lang='ru')
            tts.save(test_audio_path)
            logger.info(f"Создан тестовый аудиофайл: {test_audio_path}")
        
        # Обработка тестового аудиофайла
        audio_id = audio_processor.process_and_save_audio(
            test_audio_path,
            metadata={"test": True, "created_at": datetime.now().isoformat()}
        )
        
        logger.info(f"Тестовый аудиофайл успешно обработан и сохранен с ID: {audio_id}")
        
        # Поиск похожих аудиофайлов
        query = "тестовый аудиофайл"
        similar_audio = audio_processor.search_similar_audio(query)
        
        logger.info(f"Результаты поиска по запросу '{query}':")
        for audio in similar_audio:
            logger.info(f"ID: {audio['id']}, Файл: {audio['file_name']}, Сходство: {audio['similarity']:.4f}")
        
    except Exception as e:
        logger.error(f"Ошибка при тестировании обработки аудио: {e}")

if __name__ == "__main__":
    main()
