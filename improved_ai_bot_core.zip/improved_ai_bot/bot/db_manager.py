#!/usr/bin/env python3
"""
Модуль для управления подключением к базе данных и выполнения операций.
"""

import os
import logging
import json
from typing import List, Dict, Optional, Any, Tuple
from datetime import datetime
from sqlalchemy import create_engine, text, func, or_
from sqlalchemy.orm import sessionmaker, Session, scoped_session
from sqlalchemy.exc import SQLAlchemyError
from dotenv import load_dotenv

from database.models import Base, Document, Chunk, Category, Query, Source, DataSource, User, document_categories

# Загрузка переменных окружения
load_dotenv()

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class DatabaseManager:
    """Класс для управления подключением к базе данных и выполнения операций."""
    
    def __init__(self, database_url=None):
        """Инициализирует подключение к базе данных."""
        # Если URL базы данных не указан, используем переменные окружения или SQLite
        if database_url is None:
            # Проверяем наличие переменных окружения для PostgreSQL
            db_host = os.getenv('DB_HOST', 'localhost')
            db_port = os.getenv('DB_PORT', '5432')
            db_name = os.getenv('DB_NAME', 'deepseek_db')
            db_user = os.getenv('DB_USER', 'postgres')
            db_password = os.getenv('DB_PASSWORD', 'postgres')
            
            # Проверяем доступность PostgreSQL
            try:
                # Пробуем подключиться к PostgreSQL
                postgres_url = f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
                test_engine = create_engine(postgres_url)
                with test_engine.connect() as conn:
                    conn.execute(text("SELECT 1"))
                database_url = postgres_url
                logger.info("Успешное подключение к PostgreSQL")
            except Exception as e:
                logger.warning(f"Не удалось подключиться к PostgreSQL: {e}")
                logger.info("Использование SQLite для тестирования")
                # Используем SQLite для тестирования
                db_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'test_database.db')
                database_url = f"sqlite:///{db_path}"
        
        # Создание движка SQLAlchemy
        self.engine = create_engine(database_url)
        
        # Создание фабрики сессий
        self.Session = scoped_session(sessionmaker(bind=self.engine))
        
        # Создание таблиц, если они не существуют
        try:
            Base.metadata.create_all(self.engine)
            logger.info("Таблицы базы данных успешно созданы или уже существуют")
        except Exception as e:
            logger.error(f"Ошибка при создании таблиц: {e}")
    
    def get_session(self) -> Session:
        """Возвращает новую сессию базы данных."""
        return self.Session()
    
    # Методы для работы с документами
    def add_document(self, title: str, content: str, content_vector: Optional[List[float]] = None,
                       metadata: Optional[Dict[str, Any]] = None, source_type: Optional[str] = None,
                       category: Optional[str] = None) -> Document:
        """Создает новый документ в базе данных."""
        session = self.get_session()
        try:
            document = Document(
                title=title,
                content=content,
                meta_data=metadata,
                source_type=source_type,
                category=category
            )
            session.add(document)
            session.commit()
            
            # Если предоставлен вектор содержимого, обновляем его через SQL
            if content_vector is not None:
                try:
                    # Для PostgreSQL с расширением pgvector
                    vector_str = ','.join(map(str, content_vector))
                    session.execute(
                        text(f"UPDATE documents SET content_vector = '{vector_str}' WHERE id = {document.id}")
                    )
                    session.commit()
                except Exception as e:
                    logger.error(f"Ошибка при обновлении вектора содержимого: {e}")
            
            # Создаем копию документа с нужными данными
            doc_copy = Document(
                id=document.id,
                title=document.title,
                content=document.content,
                meta_data=document.meta_data,
                source_type=document.source_type,
                category=document.category
            )
            return doc_copy
        except Exception as e:
            session.rollback()
            logger.error(f"Ошибка при добавлении документа: {e}")
            raise
        finally:
            session.close()
    
    def get_document(self, document_id: int) -> Optional[Document]:
        """Получает документ по ID."""
        session = self.get_session()
        try:
            document = session.query(Document).filter(Document.id == document_id).first()
            if document:
                # Создаем копию документа с нужными данными
                doc_copy = Document(
                    id=document.id,
                    title=document.title,
                    content=document.content,
                    meta_data=document.meta_data,
                    source_type=document.source_type,
                    category=document.category
                )
                return doc_copy
            return None
        except Exception as e:
            logger.error(f"Ошибка при получении документа: {e}")
            return None
        finally:
            session.close()
    
    def update_document(self, document_id: int, title: Optional[str] = None, content: Optional[str] = None,
                         content_vector: Optional[List[float]] = None, metadata: Optional[Dict[str, Any]] = None,
                         source_type: Optional[str] = None, category: Optional[str] = None) -> bool:
        """Обновляет документ в базе данных."""
        session = self.get_session()
        try:
            document = session.query(Document).filter(Document.id == document_id).first()
            if not document:
                return False
            
            if title is not None:
                document.title = title
            if content is not None:
                document.content = content
            if metadata is not None:
                document.meta_data = metadata
            if source_type is not None:
                document.source_type = source_type
            if category is not None:
                document.category = category
            
            session.commit()
            
            # Если предоставлен вектор содержимого, обновляем его через SQL
            if content_vector is not None:
                try:
                    # Для PostgreSQL с расширением pgvector
                    vector_str = ','.join(map(str, content_vector))
                    session.execute(
                        text(f"UPDATE documents SET content_vector = '{vector_str}' WHERE id = {document_id}")
                    )
                    session.commit()
                except Exception as e:
                    logger.error(f"Ошибка при обновлении вектора содержимого: {e}")
            
            return True
        except Exception as e:
            session.rollback()
            logger.error(f"Ошибка при обновлении документа: {e}")
            return False
        finally:
            session.close()
    
    def delete_document(self, document_id: int) -> bool:
        """Удаляет документ из базы данных."""
        session = self.get_session()
        try:
            document = session.query(Document).filter(Document.id == document_id).first()
            if not document:
                return False
            
            session.delete(document)
            session.commit()
            return True
        except Exception as e:
            session.rollback()
            logger.error(f"Ошибка при удалении документа: {e}")
            return False
        finally:
            session.close()
    
    def get_all_documents(self, limit: int = 100, offset: int = 0) -> List[Document]:
        """Получает список всех документов с пагинацией."""
        session = self.get_session()
        try:
            documents = session.query(Document).order_by(Document.created_at.desc()).limit(limit).offset(offset).all()
            # Создаем копии документов
            doc_copies = []
            for doc in documents:
                doc_copy = Document(
                    id=doc.id,
                    title=doc.title,
                    content=doc.content,
                    meta_data=doc.meta_data,
                    source_type=doc.source_type,
                    category=doc.category
                )
                doc_copies.append(doc_copy)
            return doc_copies
        except Exception as e:
            logger.error(f"Ошибка при получении списка документов: {e}")
            return []
        finally:
            session.close()
    
    def search_documents_by_keyword(self, keyword: str, limit: int = 10) -> List[Document]:
        """Поиск документов по ключевому слову."""
        session = self.get_session()
        try:
            documents = session.query(Document).filter(
                Document.title.ilike(f"%{keyword}%") | Document.content.ilike(f"%{keyword}%")
            ).order_by(Document.created_at.desc()).limit(limit).all()
            
            # Создаем копии документов
            doc_copies = []
            for doc in documents:
                doc_copy = Document(
                    id=doc.id,
                    title=doc.title,
                    content=doc.content,
                    meta_data=doc.meta_data,
                    source_type=doc.source_type,
                    category=doc.category
                )
                doc_copies.append(doc_copy)
            return doc_copies
        except Exception as e:
            logger.error(f"Ошибка при поиске документов по ключевому слову: {e}")
            return []
        finally:
            session.close()
    
    def search_documents_by_text(self, query_text: str, limit: int = 5) -> List[Document]:
        """
        Поиск документов по тексту запроса.
        Эта функция реализует поиск документов по тексту запроса, используя полнотекстовый поиск.
        """
        session = self.get_session()
        try:
            # Разбиваем запрос на ключевые слова
            keywords = query_text.lower().split()
            
            # Создаем условия для поиска по каждому ключевому слову
            conditions = []
            for keyword in keywords:
                conditions.append(Document.title.ilike(f"%{keyword}%"))
                conditions.append(Document.content.ilike(f"%{keyword}%"))
            
            # Выполняем запрос с условиями OR для всех ключевых слов
            documents = session.query(Document).filter(
                or_(*conditions)
            ).order_by(Document.created_at.desc()).limit(limit).all()
            
            # Создаем копии документов
            doc_copies = []
            for doc in documents:
                doc_copy = Document(
                    id=doc.id,
                    title=doc.title,
                    content=doc.content,
                    meta_data=doc.meta_data,
                    source_type=doc.source_type,
                    category=doc.category
                )
                doc_copies.append(doc_copy)
            return doc_copies
        except Exception as e:
            logger.error(f"Ошибка при поиске документов по тексту: {e}")
            return []
        finally:
            session.close()
    
    def search_documents_by_vector(self, query_vector: List[float], limit: int = 5) -> List[Tuple[Document, float]]:
        """Поиск документов по векторному представлению запроса."""
        session = self.get_session()
        try:
            # Для PostgreSQL с расширением pgvector
            vector_str = ','.join(map(str, query_vector))
            
            # Пытаемся использовать pgvector для поиска
            try:
                # Запрос с использованием косинусного расстояния
                result = session.execute(
                    text(f"""
                    SELECT id, title, content, meta_data, source_type, category, 
                           1 - (content_vector <=> '{vector_str}') as similarity
                    FROM documents
                    ORDER BY similarity DESC
                    LIMIT {limit}
                    """)
                )
                
                # Обработка результатов
                documents_with_scores = []
                for row in result:
                    doc = Document(
                        id=row[0],
                        title=row[1],
                        content=row[2],
                        meta_data=row[3],
                        source_type=row[4],
                        category=row[5]
                    )
                    similarity = row[6]
                    documents_with_scores.append((doc, similarity))
                
                return documents_with_scores
            except Exception as e:
                logger.warning(f"Ошибка при использовании pgvector: {e}")
                logger.info("Переключение на поиск по ключевым словам")
                
                # Если pgvector не работает, используем поиск по ключевым словам
                # Здесь можно добавить логику для извлечения ключевых слов из вектора
                # Но для простоты просто возвращаем пустой список
                return []
        except Exception as e:
            logger.error(f"Ошибка при поиске документов по вектору: {e}")
            return []
        finally:
            session.close()
    
    def get_categories(self) -> List[Category]:
        """Получение списка категорий."""
        session = self.get_session()
        try:
            categories = session.query(Category).all()
            return categories
        except Exception as e:
            logger.error(f"Ошибка при получении списка категорий: {e}")
            return []
        finally:
            session.close()
    
    def get_documents_by_category(self, category_id: int) -> List[Document]:
        """Получение списка документов по категории."""
        session = self.get_session()
        try:
            category = session.query(Category).filter(Category.id == category_id).first()
            if not category:
                return []
            
            # Получаем документы через отношение many-to-many
            documents = category.documents
            
            # Создаем копии документов
            doc_copies = []
            for doc in documents:
                doc_copy = Document(
                    id=doc.id,
                    title=doc.title,
                    content=doc.content,
                    meta_data=doc.meta_data,
                    source_type=doc.source_type,
                    category=doc.category
                )
                doc_copies.append(doc_copy)
            
            return doc_copies
        except Exception as e:
            logger.error(f"Ошибка при получении документов категории: {e}")
            return []
        finally:
            session.close()
    
    def create_category(self, name: str, description: Optional[str] = None, parent_id: Optional[int] = None) -> Optional[Category]:
        """Создание новой категории."""
        session = self.get_session()
        try:
            category = Category(
                name=name,
                description=description,
                parent_id=parent_id
            )
            session.add(category)
            session.commit()
            
            # Создаем копию категории
            cat_copy = Category(
                id=category.id,
                name=category.name,
                description=category.description,
                parent_id=category.parent_id
            )
            
            return cat_copy
        except Exception as e:
            session.rollback()
            logger.error(f"Ошибка при создании категории: {e}")
            return None
        finally:
            session.close()
    
    def create_query(self, query_text: str, user_id: Optional[str] = None, session_id: Optional[str] = None,
                     response_text: Optional[str] = None, relevant_document_ids: Optional[List[int]] = None,
                     meta_data: Optional[Dict[str, Any]] = None) -> Optional[int]:
        """Создание записи запроса в базе данных."""
        session = self.get_session()
        try:
            # Преобразуем список ID документов в строку JSON
            relevant_docs_str = None
            if relevant_document_ids:
                relevant_docs_str = json.dumps(relevant_document_ids)
            
            query = Query(
                query_text=query_text,
                user_id=user_id,
                session_id=session_id,
                response_text=response_text,
                relevant_document_ids=relevant_docs_str,
                meta_data=meta_data
            )
            
            session.add(query)
            session.commit()
            
            return query.id
        except Exception as e:
            session.rollback()
            logger.error(f"Ошибка при создании запроса: {e}")
            return None
        finally:
            session.close()
    
    def get_query_history(self, user_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        """Получение истории запросов пользователя."""
        session = self.get_session()
        try:
            queries = session.query(Query).filter(
                Query.user_id == user_id
            ).order_by(Query.timestamp.desc()).limit(limit).all()
            
            # Преобразуем запросы в словари
            result = []
            for query in queries:
                # Преобразуем строку JSON в список ID документов
                relevant_docs = []
                if query.relevant_document_ids:
                    try:
                        relevant_docs = json.loads(query.relevant_document_ids)
                    except:
                        pass
                
                query_dict = {
                    "id": query.id,
                    "query_text": query.query_text,
                    "response_text": query.response_text,
                    "timestamp": query.timestamp.isoformat() if query.timestamp else None,
                    "relevant_document_ids": relevant_docs
                }
                
                result.append(query_dict)
            
            return result
        except Exception as e:
            logger.error(f"Ошибка при получении истории запросов: {e}")
            return []
        finally:
            session.close()
    
    def import_data(self, file_path: str, category: Optional[str] = None) -> int:
        """Импорт данных из файла."""
        # Проверяем существование файла
        if not os.path.exists(file_path):
            logger.error(f"Файл не найден: {file_path}")
            return 0
        
        # Определяем тип файла по расширению
        _, ext = os.path.splitext(file_path)
        ext = ext.lower()
        
        count = 0
        
        try:
            # Обработка в зависимости от типа файла
            if ext == '.json':
                # Импорт из JSON
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # Проверяем формат данных
                if isinstance(data, list):
                    # Список документов
                    for item in data:
                        if isinstance(item, dict) and 'title' in item and 'content' in item:
                            self.add_document(
                                title=item['title'],
                                content=item['content'],
                                metadata=item.get('metadata'),
                                source_type=item.get('source_type'),
                                category=category or item.get('category')
                            )
                            count += 1
                elif isinstance(data, dict) and 'documents' in data and isinstance(data['documents'], list):
                    # Словарь с ключом 'documents'
                    for item in data['documents']:
                        if isinstance(item, dict) and 'title' in item and 'content' in item:
                            self.add_document(
                                title=item['title'],
                                content=item['content'],
                                metadata=item.get('metadata'),
                                source_type=item.get('source_type'),
                                category=category or item.get('category')
                            )
                            count += 1
            elif ext in ['.txt', '.md']:
                # Импорт из текстового файла
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Используем имя файла как заголовок
                title = os.path.basename(file_path)
                
                self.add_document(
                    title=title,
                    content=content,
                    source_type="file",
                    category=category
                )
                count = 1
            else:
                logger.warning(f"Неподдерживаемый тип файла: {ext}")
        
        except Exception as e:
            logger.error(f"Ошибка при импорте данных: {e}")
        
        return count
