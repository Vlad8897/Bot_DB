#!/usr/bin/env python3
"""
Модуль с определением моделей SQLAlchemy для базы данных.
Содержит все модели данных, используемые в проекте.
"""

import os
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple, Union

from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Table, MetaData, JSON
from sqlalchemy.dialects.postgresql import JSONB, ARRAY
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, backref
from sqlalchemy.sql import func

# Создание базового класса для моделей SQLAlchemy
Base = declarative_base()

# Определяем тип JSON в зависимости от базы данных
def get_json_type():
    """Возвращает тип JSON в зависимости от базы данных."""
    # Проверяем наличие переменной окружения для определения типа базы данных
    db_type = os.getenv('DB_TYPE', 'sqlite').lower()
    if db_type == 'postgresql':
        return JSONB
    else:
        return JSON

# Используем функцию для определения типа JSON
JsonType = get_json_type()

# Таблица связи документов и категорий
document_categories = Table(
    'document_categories',
    Base.metadata,
    Column('document_id', Integer, ForeignKey('documents.id', ondelete='CASCADE'), primary_key=True),
    Column('category_id', Integer, ForeignKey('categories.id', ondelete='CASCADE'), primary_key=True)
)

# Определение моделей SQLAlchemy для таблиц базы данных
class Document(Base):
    """Модель для таблицы documents."""
    __tablename__ = 'documents'
    
    id = Column(Integer, primary_key=True)
    title = Column(Text, nullable=False)
    content = Column(Text, nullable=False)
    # content_vector хранится как специальный тип VECTOR в PostgreSQL
    # В SQLAlchemy мы будем работать с ним через SQL-запросы
    meta_data = Column(JsonType)
    source_type = Column(String(50))
    category = Column(String(100))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Отношения
    chunks = relationship("Chunk", back_populates="document", cascade="all, delete-orphan")
    categories = relationship("Category", secondary=document_categories, back_populates="documents")
    sources = relationship("Source", back_populates="document", cascade="all, delete-orphan")

class Chunk(Base):
    """Модель для таблицы chunks."""
    __tablename__ = 'chunks'
    
    id = Column(Integer, primary_key=True)
    document_id = Column(Integer, ForeignKey('documents.id', ondelete='CASCADE'))
    content = Column(Text, nullable=False)
    # content_vector хранится как специальный тип VECTOR в PostgreSQL
    chunk_index = Column(Integer)
    meta_data = Column(JsonType)
    created_at = Column(DateTime, default=func.now())
    
    # Отношения
    document = relationship("Document", back_populates="chunks")

class Category(Base):
    """Модель для таблицы categories."""
    __tablename__ = 'categories'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False, unique=True)
    description = Column(Text)
    parent_id = Column(Integer, ForeignKey('categories.id', ondelete='SET NULL'), nullable=True)
    created_at = Column(DateTime, default=func.now())
    
    # Отношения
    documents = relationship("Document", secondary=document_categories, back_populates="categories")
    # Самоссылающееся отношение для иерархии категорий
    children = relationship("Category", 
                          backref=backref("parent", remote_side=[id]),
                          cascade="all, delete-orphan")

class Query(Base):
    """Модель для таблицы queries."""
    __tablename__ = 'queries'
    
    id = Column(Integer, primary_key=True)
    query_text = Column(Text, nullable=False)
    # query_vector хранится как специальный тип VECTOR в PostgreSQL
    user_id = Column(String(100))
    session_id = Column(String(100))
    response_text = Column(Text)
    relevant_document_ids = Column(Text)  # Будем хранить как JSON-строку в SQLite
    meta_data = Column(JsonType)
    timestamp = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=func.now())
    
    # Отношения
    sources = relationship("Source", back_populates="query", cascade="all, delete-orphan")

class Source(Base):
    """Модель для таблицы sources."""
    __tablename__ = 'sources'
    
    id = Column(Integer, primary_key=True)
    query_id = Column(Integer, ForeignKey('queries.id'))
    document_id = Column(Integer, ForeignKey('documents.id'))
    relevance = Column(Integer)
    
    # Отношения
    query = relationship("Query", back_populates="sources")
    document = relationship("Document", back_populates="sources")

class DataSource(Base):
    """Модель для таблицы data_sources."""
    __tablename__ = 'data_sources'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    source_type = Column(String(50), nullable=False)  # file, api, database
    connection_info = Column(JsonType)
    sync_frequency = Column(String(50))
    last_synced_at = Column(DateTime)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

class User(Base):
    """Модель для таблицы users."""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(255), unique=True)
    password_hash = Column(String(255))
    api_key = Column(String(100), unique=True)
    role = Column(String(50), default='user')
    settings = Column(JsonType)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())