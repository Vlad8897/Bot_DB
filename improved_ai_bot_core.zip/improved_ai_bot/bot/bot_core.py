#!/usr/bin/env python3
"""
Основной модуль бота на основе DeepSeek для работы с базой данных.
Реализует основную логику взаимодействия с API DeepSeek и базой данных.
"""

import os
import requests
import json
import logging
import tempfile
from typing import List, Dict, Any, Optional, Tuple, Union
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import speech_recognition as sr
from pydub import AudioSegment

# Импорт модулей проекта
from database.db_manager import DatabaseManager
from database.models import Document, Category, Query

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Загрузка переменных окружения
load_dotenv()

# Параметры подключения к базе данных
DATABASE_URL = os.getenv("DATABASE_URL", f"postgresql://{os.getenv('DB_USER', 'postgres')}:{os.getenv('DB_PASSWORD', 'postgres')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '5432')}/{os.getenv('DB_NAME', 'deepseek_bot')}")

class DeepSeekBot:
    def __init__(self):
        """Инициализация бота DeepSeek."""
        self.api_key = os.getenv("DEEPSEEK_API_KEY", "your_api_key_here")
        self.api_base_url = os.getenv("DEEPSEEK_API_BASE_URL", "https://api.deepseek.com")
        self.api_url = f"{self.api_base_url}/v1/chat/completions"
        self.db_manager = DatabaseManager(DATABASE_URL)
        
        # Проверка подключения к базе данных
        try:
            self.db_manager.get_session()
            logger.info("Успешное подключение к базе данных.")
        except Exception as e:
            logger.error(f"Ошибка подключения к базе данных: {e}")
            # Если не удалось подключиться к PostgreSQL, используем SQLite
            sqlite_url = "sqlite:///./deepseek_bot.db"
            logger.info(f"Переключение на SQLite: {sqlite_url}")
            self.db_manager = DatabaseManager(sqlite_url)
        
    def get_session(self):
        """Получение сессии для работы с базой данных."""
        return self.db_manager.get_session()

    def generate_response(self, prompt, context=None):
        """Генерация ответа с использованием API DeepSeek."""
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        messages = []
        
        # Добавление контекста, если он есть
        if context:
            messages.append({"role": "system", "content": context})
        
        # Добавление запроса пользователя
        messages.append({"role": "user", "content": prompt})
        
        data = {
            "model": "deepseek-chat",
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 1000
        }
        
        try:
            response = requests.post(self.api_url, headers=headers, data=json.dumps(data))
            response.raise_for_status()  # Проверка на ошибки HTTP
            result = response.json()
            
            if "choices" in result and len(result["choices"]) > 0:
                return result["choices"][0]["message"]["content"]
            else:
                return "Не удалось получить ответ от API DeepSeek."
        except Exception as e:
            logger.error(f"Ошибка при обращении к API DeepSeek: {e}")
            # Если API недоступен, возвращаем заглушку для тестирования
            return f"Это тестовый ответ, так как произошла ошибка при обращении к API DeepSeek: {e}"

    def process_query(self, query_text, user_id=None):
        """
        Обработка запроса пользователя.
        Ищет релевантную информацию в базе данных и генерирует ответ.
        """
        try:
            # Поиск документов по тексту запроса
            documents = self.db_manager.search_documents_by_text(query_text, limit=5)
            
            if not documents:
                # Если документы не найдены, генерируем общий ответ
                response_text = self.generate_response(
                    query_text, 
                    "Вы - помощник, который отвечает на вопросы пользователя."
                )
                
                # Сохраняем запрос в базе данных
                self.db_manager.create_query(
                    query_text=query_text,
                    user_id=user_id,
                    response_text=response_text
                )
                
                return {
                    "query": query_text,
                    "response": response_text,
                    "documents": []
                }
            
            # Формируем контекст из найденных документов
            context = "Информация из базы данных:\n\n"
            for i, doc in enumerate(documents):
                context += f"Документ {i+1}: {doc.title}\n{doc.content}\n\n"
            
            # Формируем промпт для DeepSeek
            prompt = f"""На основе следующей информации из базы данных, ответьте на вопрос пользователя.
            
{context}

Вопрос пользователя: {query_text}

Ответ:"""
            
            # Генерация ответа
            response_text = self.generate_response(prompt)
            
            # Сохраняем запрос в базе данных
            self.db_manager.create_query(
                query_text=query_text,
                user_id=user_id,
                response_text=response_text,
                relevant_document_ids=[doc.id for doc in documents]
            )
            
            return {
                "query": query_text,
                "response": response_text,
                "documents": [{"id": doc.id, "title": doc.title} for doc in documents]
            }
            
        except Exception as e:
            logger.error(f"Ошибка при обработке запроса: {e}")
            return {
                "query": query_text,
                "response": f"Произошла ошибка при обработке запроса: {str(e)}",
                "documents": []
            }

    def process_audio_query(self, audio_file_path, user_id=None):
        """
        Обработка аудиозапроса пользователя.
        Преобразует аудио в текст, затем обрабатывает как текстовый запрос.
        """
        try:
            # Преобразование аудио в текст
            query_text = self.transcribe_audio(audio_file_path)
            
            if not query_text:
                return {
                    "query": "Аудиозапрос",
                    "response": "Не удалось распознать текст в аудиофайле.",
                    "documents": []
                }
            
            # Обработка текстового запроса
            result = self.process_query(query_text, user_id)
            
            # Добавляем информацию о распознанном тексте
            result["transcribed_text"] = query_text
            
            return result
            
        except Exception as e:
            logger.error(f"Ошибка при обработке аудиозапроса: {e}")
            return {
                "query": "Аудиозапрос",
                "response": f"Произошла ошибка при обработке аудиозапроса: {str(e)}",
                "documents": []
            }

    def transcribe_audio(self, audio_file_path):
        """
        Преобразование аудиофайла в текст.
        Поддерживает форматы mp3, wav, ogg.
        """
        try:
            # Определение формата аудиофайла
            file_ext = os.path.splitext(audio_file_path)[1].lower()
            
            # Создаем временный WAV файл для распознавания
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_wav:
                temp_wav_path = temp_wav.name
            
            # Конвертация в WAV, если нужно
            if file_ext == '.mp3':
                audio = AudioSegment.from_mp3(audio_file_path)
                audio.export(temp_wav_path, format="wav")
            elif file_ext == '.ogg':
                audio = AudioSegment.from_ogg(audio_file_path)
                audio.export(temp_wav_path, format="wav")
            elif file_ext == '.wav':
                # Если уже WAV, просто копируем
                with open(audio_file_path, 'rb') as src, open(temp_wav_path, 'wb') as dst:
                    dst.write(src.read())
            else:
                logger.error(f"Неподдерживаемый формат аудиофайла: {file_ext}")
                return None
            
            # Распознавание речи
            recognizer = sr.Recognizer()
            with sr.AudioFile(temp_wav_path) as source:
                audio_data = recognizer.record(source)
                text = recognizer.recognize_google(audio_data, language='ru-RU')
            
            # Удаляем временный файл
            os.unlink(temp_wav_path)
            
            return text
            
        except sr.UnknownValueError:
            logger.error("Не удалось распознать речь в аудиофайле")
            return None
        except sr.RequestError as e:
            logger.error(f"Ошибка сервиса распознавания речи: {e}")
            return None
        except Exception as e:
            logger.error(f"Ошибка при транскрибации аудио: {e}")
            return None

    def get_categories(self):
        """Получение списка категорий."""
        try:
            categories = self.db_manager.get_categories()
            return [{"id": cat.id, "name": cat.name, "description": cat.description} for cat in categories]
        except Exception as e:
            logger.error(f"Ошибка при получении списка категорий: {e}")
            return []

    def get_documents_by_category(self, category_id):
        """Получение списка документов по категории."""
        try:
            documents = self.db_manager.get_documents_by_category(category_id)
            return [{"id": doc.id, "title": doc.title, "content": doc.content} for doc in documents]
        except Exception as e:
            logger.error(f"Ошибка при получении документов категории: {e}")
            return []

    def get_document_by_id(self, document_id):
        """Получение документа по ID."""
        try:
            document = self.db_manager.get_document(document_id)
            if document:
                return {
                    "id": document.id,
                    "title": document.title,
                    "content": document.content,
                    "source_type": document.source_type,
                    "category": document.category,
                    "created_at": document.created_at.isoformat() if document.created_at else None,
                    "updated_at": document.updated_at.isoformat() if document.updated_at else None
                }
            return None
        except Exception as e:
            logger.error(f"Ошибка при получении документа: {e}")
            return None

    def get_all_documents(self, limit=100):
        """Получение всех документов."""
        try:
            documents = self.db_manager.get_all_documents(limit)
            return [
                {
                    "id": doc.id,
                    "title": doc.title,
                    "content": doc.content[:200] + "..." if len(doc.content) > 200 else doc.content,
                    "category": doc.category,
                    "created_at": doc.created_at.isoformat() if doc.created_at else None
                } 
                for doc in documents
            ]
        except Exception as e:
            logger.error(f"Ошибка при получении всех документов: {e}")
            return []

    def add_document(self, title, content, category=None, metadata=None, source_type=None):
        """Добавление документа в базу данных."""
        try:
            document = self.db_manager.create_document(
                title=title,
                content=content,
                metadata=metadata,
                source_type=source_type,
                category=category
            )
            return document
        except Exception as e:
            logger.error(f"Ошибка при добавлении документа: {e}")
            raise

    def import_data(self, file_path, category=None):
        """Импорт данных из файла."""
        try:
            # Определение типа файла
            file_ext = os.path.splitext(file_path)[1].lower()
            
            # Если это аудиофайл, транскрибируем его
            if file_ext in ['.mp3', '.wav', '.ogg']:
                text = self.transcribe_audio(file_path)
                if text:
                    # Создаем документ с транскрибированным текстом
                    file_name = os.path.basename(file_path)
                    document = self.add_document(
                        title=f"Транскрипция аудио: {file_name}",
                        content=text,
                        category=category,
                        metadata={"source_file": file_name, "file_type": "audio"},
                        source_type="audio"
                    )
                    return 1  # Добавлен один документ
                else:
                    return 0  # Не удалось транскрибировать
            
            # Для других типов файлов используем стандартный импорт
            count = self.db_manager.import_data(file_path, category)
            return count
        except Exception as e:
            logger.error(f"Ошибка при импорте данных: {e}")
            return 0

    def search_documents(self, query_text, limit=10):
        """Поиск документов по тексту."""
        try:
            documents = self.db_manager.search_documents_by_text(query_text, limit)
            return [
                {
                    "id": doc.id,
                    "title": doc.title,
                    "content": doc.content[:200] + "..." if len(doc.content) > 200 else doc.content,
                    "category": doc.category,
                    "relevance": doc.relevance if hasattr(doc, 'relevance') else None
                } 
                for doc in documents
            ]
        except Exception as e:
            logger.error(f"Ошибка при поиске документов: {e}")
            return []

    def get_query_history(self, user_id, limit=100):
        """Получение истории запросов пользователя."""
        try:
            queries = self.db_manager.get_query_history(user_id, limit)
            return [
                {
                    "id": query.id,
                    "query_text": query.query_text,
                    "response_text": query.response_text,
                    "timestamp": query.timestamp.isoformat() if query.timestamp else None,
                    "relevant_document_ids": query.relevant_document_ids or []
                }
                for query in queries
            ]
        except Exception as e:
            logger.error(f"Ошибка при получении истории запросов: {e}")
            return []

# Пример использования
if __name__ == "__main__":
    bot = DeepSeekBot()
    print("Бот готов к общению! Напишите 'выход', чтобы завершить.")
    
    while True:
        user_input = input("Вы: ")
        if user_input.lower() == "выход":
            print("Бот: До свидания!")
            break

        # Обработка запроса
        result = bot.process_query(user_input)
        print(f"Бот: {result['response']}")
