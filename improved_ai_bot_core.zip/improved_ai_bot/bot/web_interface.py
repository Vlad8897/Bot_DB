#!/usr/bin/env python3
"""
Модуль для создания веб-интерфейса бота на основе Flask.
"""

import os
import logging
import json
from typing import Dict, Any, List, Optional
from flask import Flask, render_template, request, jsonify, flash, redirect, url_for, session
from flask_cors import CORS
from werkzeug.utils import secure_filename
from datetime import datetime

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Создание экземпляра Flask
app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'deepseek_bot_secret_key')
CORS(app)  # Включаем CORS для API

# Директория для загрузки файлов
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB

# Разрешенные расширения файлов
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'doc', 'docx', 'md', 'json', 'mp3', 'wav', 'ogg'}

def allowed_file(filename):
    """Проверяет, разрешено ли загружать файл с данным расширением."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

class WebInterface:
    """Класс для создания веб-интерфейса бота."""
    
    def __init__(self, bot):
        """Инициализирует веб-интерфейс с экземпляром бота."""
        self.bot = bot
        
        # Регистрация маршрутов
        self.register_routes()
        
        # Создание шаблонов
        create_templates()
    
    def register_routes(self):
        """Регистрирует маршруты Flask."""
        # Привязываем методы класса к маршрутам Flask
        app.add_url_rule('/', 'index', self.index)
        app.add_url_rule('/query', 'query', self.query, methods=['GET', 'POST'])
        app.add_url_rule('/documents', 'documents', self.documents)
        app.add_url_rule('/document/<int:document_id>', 'document', self.document)
        app.add_url_rule('/add_document', 'add_document', self.add_document, methods=['GET', 'POST'])
        app.add_url_rule('/import_data', 'import_data', self.import_data, methods=['GET', 'POST'])
        app.add_url_rule('/search', 'search', self.search, methods=['GET', 'POST'])
        app.add_url_rule('/categories', 'categories', self.categories)
        app.add_url_rule('/history', 'history', self.history)
        
        # API маршруты
        app.add_url_rule('/api/query', 'api_query', self.api_query, methods=['POST'])
        app.add_url_rule('/api/search', 'api_search', self.api_search, methods=['GET'])
        app.add_url_rule('/api/document/<int:document_id>', 'api_document', self.api_document, methods=['GET'])
        app.add_url_rule('/api/upload', 'api_upload', self.api_upload, methods=['POST'])
        app.add_url_rule('/api/history', 'api_history', self.api_history, methods=['GET'])
    
    def run(self, host='0.0.0.0', port=5000, debug=False):
        """Запускает веб-сервер Flask."""
        app.run(host=host, port=port, debug=debug)
    
    # Маршруты веб-интерфейса
    def index(self):
        """Главная страница."""
        return render_template('index.html')
    
    def query(self):
        """Страница для отправки запроса боту."""
        if request.method == 'POST':
            query_text = request.form.get('query')
            user_id = session.get('user_id', 'web_user')
            
            if not query_text:
                flash('Пожалуйста, введите запрос', 'warning')
                return render_template('query.html')
            
            try:
                result = self.bot.process_query(query_text, user_id)
                return render_template('query.html', query=query_text, result=result)
            
            except Exception as e:
                logger.error(f"Ошибка при обработке запроса: {e}")
                flash(f'Ошибка при обработке запроса: {str(e)}', 'danger')
                return render_template('query.html', query=query_text)
        
        return render_template('query.html')
    
    def documents(self):
        """Страница со списком документов."""
        try:
            documents = self.bot.get_all_documents()
            return render_template('documents.html', documents=documents)
        
        except Exception as e:
            logger.error(f"Ошибка при получении списка документов: {e}")
            flash(f'Ошибка при получении списка документов: {str(e)}', 'danger')
            return render_template('documents.html', documents=[])
    
    def document(self, document_id):
        """Страница с информацией о документе."""
        try:
            document = self.bot.get_document_by_id(document_id)
            
            if document:
                return render_template('document.html', document=document)
            else:
                flash(f'Документ с ID {document_id} не найден', 'warning')
                return redirect(url_for('documents'))
        
        except Exception as e:
            logger.error(f"Ошибка при получении документа: {e}")
            flash(f'Ошибка при получении документа: {str(e)}', 'danger')
            return redirect(url_for('documents'))
    
    def add_document(self):
        """Страница для добавления нового документа."""
        if request.method == 'POST':
            title = request.form.get('title')
            content = request.form.get('content')
            category = request.form.get('category')
            
            if not title or not content:
                flash('Пожалуйста, заполните все обязательные поля', 'warning')
                return render_template('add_document.html')
            
            try:
                document = self.bot.add_document(title, content, category)
                flash(f'Документ "{title}" успешно добавлен', 'success')
                return redirect(url_for('document', document_id=document.id))
            
            except Exception as e:
                logger.error(f"Ошибка при добавлении документа: {e}")
                flash(f'Ошибка при добавлении документа: {str(e)}', 'danger')
                return render_template('add_document.html', title=title, content=content, category=category)
        
        return render_template('add_document.html')
    
    def import_data(self):
        """Страница для импорта данных из файла."""
        if request.method == 'POST':
            # Проверяем, есть ли файл в запросе
            if 'file' not in request.files:
                flash('Файл не выбран', 'warning')
                return render_template('import_data.html')
            
            file = request.files['file']
            category = request.form.get('category')
            
            # Если пользователь не выбрал файл
            if file.filename == '':
                flash('Файл не выбран', 'warning')
                return render_template('import_data.html')
            
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                
                try:
                    count = self.bot.import_data(filepath, category)
                    flash(f'Успешно импортировано {count} документов', 'success')
                    return redirect(url_for('documents'))
                
                except Exception as e:
                    logger.error(f"Ошибка при импорте данных: {e}")
                    flash(f'Ошибка при импорте данных: {str(e)}', 'danger')
                    return render_template('import_data.html')
            else:
                flash(f'Недопустимый тип файла. Разрешены только: {", ".join(ALLOWED_EXTENSIONS)}', 'warning')
                return render_template('import_data.html')
        
        return render_template('import_data.html')
    
    def search(self):
        """Страница поиска документов."""
        query = request.args.get('query', '')
        
        if query:
            try:
                results = self.bot.search_documents(query)
                return render_template('search.html', query=query, results=results)
            
            except Exception as e:
                logger.error(f"Ошибка при поиске документов: {e}")
                flash(f'Ошибка при поиске документов: {str(e)}', 'danger')
                return render_template('search.html', query=query, results=[])
        
        return render_template('search.html')
    
    def categories(self):
        """Страница со списком категорий."""
        try:
            categories = self.bot.get_categories()
            return render_template('categories.html', categories=categories)
        
        except Exception as e:
            logger.error(f"Ошибка при получении списка категорий: {e}")
            flash(f'Ошибка при получении списка категорий: {str(e)}', 'danger')
            return render_template('categories.html', categories=[])
    
    def history(self):
        """Страница с историей запросов."""
        try:
            user_id = session.get('user_id', 'web_user')
            history = self.bot.get_query_history(user_id, 100)
            return render_template('history.html', history=history)
        
        except Exception as e:
            logger.error(f"Ошибка при получении истории запросов: {e}")
            flash(f'Ошибка при получении истории запросов: {str(e)}', 'danger')
            return render_template('history.html', history=[])
    
    # API маршруты
    def api_query(self):
        """API для обработки запроса."""
        data = request.json
        
        if not data or 'query' not in data:
            return jsonify({'error': 'Необходимо указать параметр query'}), 400
        
        query_text = data['query']
        user_id = data.get('user_id', 'api_user')
        
        try:
            result = self.bot.process_query(query_text, user_id)
            return jsonify(result)
        
        except Exception as e:
            logger.error(f"API ошибка при обработке запроса: {e}")
            return jsonify({'error': str(e)}), 500
    
    def api_search(self):
        """API для поиска документов."""
        query_text = request.args.get('query')
        limit = request.args.get('limit', 10, type=int)
        
        if not query_text:
            return jsonify({'error': 'Необходимо указать параметр query'}), 400
        
        try:
            results = self.bot.search_documents(query_text, limit)
            return jsonify(results)
        
        except Exception as e:
            logger.error(f"API ошибка при поиске документов: {e}")
            return jsonify({'error': str(e)}), 500
    
    def api_document(self, document_id):
        """API для получения документа по ID."""
        try:
            document = self.bot.get_document_by_id(document_id)
            
            if document:
                return jsonify(document)
            else:
                return jsonify({'error': f'Документ с ID {document_id} не найден'}), 404
        
        except Exception as e:
            logger.error(f"API ошибка при получении документа: {e}")
            return jsonify({'error': str(e)}), 500
    
    def api_upload(self):
        """API для загрузки файлов."""
        try:
            data = request.json
            
            if not data:
                return jsonify({'error': 'Данные не предоставлены'}), 400
            
            file_name = data.get('fileName')
            file_id = data.get('fileId')
            file_url = data.get('fileUrl')
            file_type = data.get('fileType')
            is_audio = data.get('isAudio', False)
            category = data.get('category')
            
            if not file_name or not file_id or not file_url:
                return jsonify({'error': 'Необходимо указать fileName, fileId и fileUrl'}), 400
            
            # Полный путь к файлу
            file_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'web-app/public', file_url.lstrip('/'))
            
            # Проверяем существование файла
            if not os.path.exists(file_path):
                return jsonify({'error': f'Файл не найден: {file_path}'}), 404
            
            # Обработка в зависимости от типа файла
            if is_audio:
                # Здесь будет код для обработки аудиофайла
                # Например, транскрибация и сохранение в базу данных
                result = {
                    'status': 'success',
                    'message': 'Аудиофайл успешно обработан',
                    'file_id': file_id,
                    'file_name': file_name,
                    'file_type': file_type,
                    'category': category,
                    'processed': True
                }
            else:
                # Импорт текстового файла в базу данных
                count = self.bot.import_data(file_path, category)
                result = {
                    'status': 'success',
                    'message': f'Файл успешно импортирован, добавлено {count} документов',
                    'file_id': file_id,
                    'file_name': file_name,
                    'file_type': file_type,
                    'category': category,
                    'documents_added': count
                }
            
            return jsonify(result)
        
        except Exception as e:
            logger.error(f"API ошибка при загрузке файла: {e}")
            return jsonify({'error': str(e)}), 500
    
    def api_history(self):
        """API для получения истории запросов."""
        user_id = request.args.get('user_id', 'api_user')
        limit = request.args.get('limit', 100, type=int)
        
        try:
            history = self.bot.get_query_history(user_id, limit)
            return jsonify(history)
        
        except Exception as e:
            logger.error(f"API ошибка при получении истории запросов: {e}")
            return jsonify({'error': str(e)}), 500

@app.route('/set_user', methods=['POST'])
def set_user():
    """Установка текущего пользователя."""
    user_id = request.form.get('user_id')
    
    if user_id:
        session['user_id'] = user_id
        flash(f'Текущий пользователь установлен: {user_id}', 'success')
    
    return redirect(request.referrer or url_for('index'))

@app.errorhandler(404)
def page_not_found(e):
    """Обработчик ошибки 404."""
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    """Обработчик ошибки 500."""
    return render_template('500.html'), 500

def create_templates():
    """Создает шаблоны для веб-интерфейса."""
    templates_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
    static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
    
    # Создаем директории, если они не существуют
    os.makedirs(templates_dir, exist_ok=True)
    os.makedirs(static_dir, exist_ok=True)
    os.makedirs(os.path.join(static_dir, 'css'), exist_ok=True)
    os.makedirs(os.path.join(static_dir, 'js'), exist_ok=True)
    
    # Создаем базовый шаблон
    with open(os.path.join(templates_dir, 'base.html'), 'w') as f:
        f.write('''<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}DeepSeek Bot{% endblock %}</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{ url_for('static', filename='css/style.css') }}">
    {% block head %}{% endblock %}
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="{{ url_for('index') }}">DeepSeek Bot</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url_for('index') }}">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url_for('query') }}">Запрос</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url_for('documents') }}">Документы</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url_for('add_document') }}">Добавить документ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url_for('import_data') }}">Импорт данных</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url_for('search') }}">Поиск</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url_for('categories') }}">Категории</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url_for('history') }}">История</a>
                    </li>
                </ul>
                <div class="ms-auto">
                    <form action="{{ url_for('set_user') }}" method="post" class="d-flex">
                        <input type="hidden" name="csrf_token" value="{{ csrf_token() }}">
                        <input type="text" name="user_id" class="form-control form-control-sm me-2" placeholder="ID пользователя" value="{{ session.get('user_id', '') }}">
                        <button type="submit" class="btn btn-sm btn-light">Установить</button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                    <div class="alert alert-{{ category }}">{{ message }}</div>
                {% endfor %}
            {% endif %}
        {% endwith %}

        {% block content %}{% endblock %}
    </div>

    <footer class="footer mt-5 py-3 bg-light">
        <div class="container text-center">
            <span class="text-muted">© 2025 DeepSeek Bot</span>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="{{ url_for('static', filename='js/script.js') }}"></script>
    {% block scripts %}{% endblock %}
</body>
</html>''')
    
    # Создаем CSS файл
    with open(os.path.join(static_dir, 'css', 'style.css'), 'w') as f:
        f.write('''/* Основные стили */
body {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

.footer {
    margin-top: auto;
}

/* Стили для карточек документов */
.document-card {
    transition: transform 0.3s;
}

.document-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.1);
}

/* Стили для формы запроса */
.query-form {
    background-color: #f8f9fa;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 20px;
}

/* Стили для результатов запроса */
.query-result {
    background-color: #f0f8ff;
    padding: 15px;
    border-radius: 10px;
    border-left: 5px solid #007bff;
}

/* Стили для истории запросов */
.history-item {
    margin-bottom: 15px;
    padding: 10px;
    border-radius: 5px;
    background-color: #f8f9fa;
}

.history-item:hover {
    background-color: #e9ecef;
}

/* Стили для аудио-плеера */
.audio-player {
    width: 100%;
    margin: 10px 0;
}

/* Адаптивные стили */
@media (max-width: 768px) {
    .navbar-nav {
        flex-direction: column;
    }
    
    .ms-auto {
        margin-top: 10px;
    }
}''')
    
    # Создаем JS файл
    with open(os.path.join(static_dir, 'js', 'script.js'), 'w') as f:
        f.write('''// Общие функции JavaScript

// Функция для копирования текста в буфер обмена
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        alert('Текст скопирован в буфер обмена');
    }, function(err) {
        console.error('Не удалось скопировать текст: ', err);
    });
}

// Функция для отображения уведомлений
function showNotification(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.role = 'alert';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    const container = document.querySelector('.container');
    container.insertBefore(alertDiv, container.firstChild);
    
    // Автоматически скрываем уведомление через 5 секунд
    setTimeout(() => {
        alertDiv.classList.remove('show');
        setTimeout(() => alertDiv.remove(), 150);
    }, 5000);
}

// Инициализация всплывающих подсказок Bootstrap
document.addEventListener('DOMContentLoaded', function() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});''')
    
    # Создаем шаблон главной страницы
    with open(os.path.join(templates_dir, 'index.html'), 'w') as f:
        f.write('''{% extends 'base.html' %}

{% block title %}DeepSeek Bot - Главная{% endblock %}

{% block content %}
<div class="jumbotron">
    <h1 class="display-4">Добро пожаловать в DeepSeek Bot!</h1>
    <p class="lead">Интеллектуальный бот на основе DeepSeek для работы с документами и ответов на вопросы.</p>
    <hr class="my-4">
    <p>Используйте навигационное меню для доступа к различным функциям бота.</p>
    <div class="d-grid gap-2 d-md-flex justify-content-md-start">
        <a href="{{ url_for('query') }}" class="btn btn-primary btn-lg">Задать вопрос</a>
        <a href="{{ url_for('documents') }}" class="btn btn-secondary btn-lg">Просмотреть документы</a>
    </div>
</div>

<div class="row mt-5">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Задайте вопрос</h5>
                <p class="card-text">Получите ответы на ваши вопросы, основанные на информации из базы знаний.</p>
                <a href="{{ url_for('query') }}" class="btn btn-primary">Перейти</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Управление документами</h5>
                <p class="card-text">Просматривайте, добавляйте и управляйте документами в базе знаний.</p>
                <a href="{{ url_for('documents') }}" class="btn btn-primary">Перейти</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">История запросов</h5>
                <p class="card-text">Просмотрите историю ваших запросов и полученных ответов.</p>
                <a href="{{ url_for('history') }}" class="btn btn-primary">Перейти</a>
            </div>
        </div>
    </div>
</div>
{% endblock %}''')
    
    # Создаем шаблон страницы запроса
    with open(os.path.join(templates_dir, 'query.html'), 'w') as f:
        f.write('''{% extends 'base.html' %}

{% block title %}DeepSeek Bot - Запрос{% endblock %}

{% block content %}
<h1>Задайте вопрос боту</h1>
<p class="lead">Введите ваш вопрос, и бот найдет ответ на основе имеющихся данных.</p>

<div class="query-form">
    <form method="post" action="{{ url_for('query') }}">
        <input type="hidden" name="csrf_token" value="{{ csrf_token() }}">
        <div class="mb-3">
            <label for="query" class="form-label">Ваш вопрос:</label>
            <textarea class="form-control" id="query" name="query" rows="3" required>{{ query }}</textarea>
        </div>
        <button type="submit" class="btn btn-primary">Отправить запрос</button>
    </form>
</div>

{% if result %}
<h2>Ответ:</h2>
<div class="query-result">
    <p>{{ result.response }}</p>
    
    {% if result.sources %}
    <h3>Источники:</h3>
    <ul>
        {% for source in result.sources %}
        <li>
            <a href="{{ url_for('document', document_id=source.document_id) }}">{{ source.title }}</a>
            (релевантность: {{ source.relevance }})
        </li>
        {% endfor %}
    </ul>
    {% endif %}
</div>
{% endif %}
{% endblock %}''')
    
    # Создаем шаблон страницы документов
    with open(os.path.join(templates_dir, 'documents.html'), 'w') as f:
        f.write('''{% extends 'base.html' %}

{% block title %}DeepSeek Bot - Документы{% endblock %}

{% block content %}
<h1>Документы</h1>
<p class="lead">Список всех документов в базе знаний.</p>

<div class="mb-3">
    <a href="{{ url_for('add_document') }}" class="btn btn-primary">Добавить документ</a>
    <a href="{{ url_for('import_data') }}" class="btn btn-secondary">Импортировать данные</a>
</div>

{% if documents %}
<div class="row">
    {% for document in documents %}
    <div class="col-md-4 mb-4">
        <div class="card document-card h-100">
            <div class="card-body">
                <h5 class="card-title">{{ document.title }}</h5>
                <h6 class="card-subtitle mb-2 text-muted">{{ document.category or 'Без категории' }}</h6>
                <p class="card-text">{{ document.content[:100] }}{% if document.content|length > 100 %}...{% endif %}</p>
            </div>
            <div class="card-footer">
                <a href="{{ url_for('document', document_id=document.id) }}" class="btn btn-sm btn-primary">Подробнее</a>
            </div>
        </div>
    </div>
    {% endfor %}
</div>
{% else %}
<div class="alert alert-info">
    В базе данных нет документов. <a href="{{ url_for('add_document') }}">Добавьте новый документ</a> или <a href="{{ url_for('import_data') }}">импортируйте данные</a>.
</div>
{% endif %}
{% endblock %}''')
    
    # Создаем шаблон страницы документа
    with open(os.path.join(templates_dir, 'document.html'), 'w') as f:
        f.write('''{% extends 'base.html' %}

{% block title %}DeepSeek Bot - Документ{% endblock %}

{% block content %}
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>{{ document.title }}</h1>
    <div>
        <a href="{{ url_for('documents') }}" class="btn btn-secondary">Назад к списку</a>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between">
        <span>Категория: {{ document.category or 'Без категории' }}</span>
        <span>ID: {{ document.id }}</span>
    </div>
    <div class="card-body">
        <h5 class="card-title">Содержание:</h5>
        <div class="card-text">{{ document.content|nl2br }}</div>
    </div>
    <div class="card-footer text-muted">
        Создан: {{ document.created_at.strftime('%d.%m.%Y %H:%M') if document.created_at else 'Неизвестно' }}
        {% if document.updated_at %}
        <br>Обновлен: {{ document.updated_at.strftime('%d.%m.%Y %H:%M') }}
        {% endif %}
    </div>
</div>

{% if document.meta_data %}
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">Метаданные</h5>
    </div>
    <div class="card-body">
        <pre>{{ document.meta_data|tojson(indent=2) }}</pre>
    </div>
</div>
{% endif %}

<div class="d-flex justify-content-between">
    <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal">Удалить документ</button>
    <a href="#" class="btn btn-primary">Редактировать</a>
</div>

<!-- Модальное окно подтверждения удаления -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Подтверждение удаления</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Вы уверены, что хотите удалить документ "{{ document.title }}"?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                <form action="{{ url_for('delete_document', document_id=document.id) }}" method="post">
                    <input type="hidden" name="csrf_token" value="{{ csrf_token() }}">
                    <button type="submit" class="btn btn-danger">Удалить</button>
                </form>
            </div>
        </div>
    </div>
</div>
{% endblock %}''')
    
    # Создаем шаблон страницы добавления документа
    with open(os.path.join(templates_dir, 'add_document.html'), 'w') as f:
        f.write('''{% extends 'base.html' %}

{% block title %}DeepSeek Bot - Добавление документа{% endblock %}

{% block content %}
<h1>Добавление нового документа</h1>
<p class="lead">Заполните форму для добавления нового документа в базу знаний.</p>

<form method="post" action="{{ url_for('add_document') }}">
    <input type="hidden" name="csrf_token" value="{{ csrf_token() }}">
    <div class="mb-3">
        <label for="title" class="form-label">Заголовок:</label>
        <input type="text" class="form-control" id="title" name="title" value="{{ title }}" required>
    </div>
    <div class="mb-3">
        <label for="category" class="form-label">Категория:</label>
        <input type="text" class="form-control" id="category" name="category" value="{{ category }}">
        <div class="form-text">Оставьте пустым, если документ не относится к определенной категории.</div>
    </div>
    <div class="mb-3">
        <label for="content" class="form-label">Содержание:</label>
        <textarea class="form-control" id="content" name="content" rows="10" required>{{ content }}</textarea>
    </div>
    <button type="submit" class="btn btn-primary">Добавить документ</button>
    <a href="{{ url_for('documents') }}" class="btn btn-secondary">Отмена</a>
</form>
{% endblock %}''')
    
    # Создаем шаблон страницы импорта данных
    with open(os.path.join(templates_dir, 'import_data.html'), 'w') as f:
        f.write('''{% extends 'base.html' %}

{% block title %}DeepSeek Bot - Импорт данных{% endblock %}

{% block content %}
<h1>Импорт данных</h1>
<p class="lead">Загрузите файл для импорта данных в базу знаний.</p>

<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">Поддерживаемые форматы файлов</h5>
    </div>
    <div class="card-body">
        <ul>
            <li><strong>Текстовые файлы (.txt)</strong> - Простой текст, каждый файл будет импортирован как один документ.</li>
            <li><strong>Markdown файлы (.md)</strong> - Форматированный текст в формате Markdown.</li>
            <li><strong>JSON файлы (.json)</strong> - Структурированные данные в формате JSON. Должны содержать массив объектов с полями "title" и "content".</li>
            <li><strong>PDF файлы (.pdf)</strong> - Документы в формате PDF.</li>
            <li><strong>Word документы (.doc, .docx)</strong> - Документы Microsoft Word.</li>
            <li><strong>Аудиофайлы (.mp3, .wav, .ogg)</strong> - Аудиозаписи для транскрибации.</li>
        </ul>
    </div>
</div>

<form method="post" action="{{ url_for('import_data') }}" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="{{ csrf_token() }}">
    <div class="mb-3">
        <label for="file" class="form-label">Выберите файл:</label>
        <input type="file" class="form-control" id="file" name="file" required>
    </div>
    <div class="mb-3">
        <label for="category" class="form-label">Категория:</label>
        <input type="text" class="form-control" id="category" name="category">
        <div class="form-text">Оставьте пустым, если документы не относятся к определенной категории.</div>
    </div>
    <button type="submit" class="btn btn-primary">Импортировать</button>
    <a href="{{ url_for('documents') }}" class="btn btn-secondary">Отмена</a>
</form>
{% endblock %}''')
    
    # Создаем шаблон страницы поиска
    with open(os.path.join(templates_dir, 'search.html'), 'w') as f:
        f.write('''{% extends 'base.html' %}

{% block title %}DeepSeek Bot - Поиск{% endblock %}

{% block content %}
<h1>Поиск документов</h1>
<p class="lead">Введите ключевые слова для поиска документов в базе знаний.</p>

<form method="get" action="{{ url_for('search') }}" class="mb-4">
    <div class="input-group">
        <input type="text" class="form-control" name="query" placeholder="Введите поисковый запрос" value="{{ query }}" required>
        <button class="btn btn-primary" type="submit">Поиск</button>
    </div>
</form>

{% if query %}
    {% if results %}
        <h2>Результаты поиска по запросу "{{ query }}":</h2>
        <div class="list-group">
            {% for result in results %}
                <a href="{{ url_for('document', document_id=result.id) }}" class="list-group-item list-group-item-action">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1">{{ result.title }}</h5>
                        {% if result.relevance %}
                            <small>Релевантность: {{ "%.2f"|format(result.relevance) }}</small>
                        {% endif %}
                    </div>
                    <p class="mb-1">{{ result.content[:200] }}{% if result.content|length > 200 %}...{% endif %}</p>
                    <small>Категория: {{ result.category or 'Без категории' }}</small>
                </a>
            {% endfor %}
        </div>
    {% else %}
        <div class="alert alert-info">
            По запросу "{{ query }}" ничего не найдено. Попробуйте изменить поисковый запрос.
        </div>
    {% endif %}
{% endif %}
{% endblock %}''')
    
    # Создаем шаблон страницы категорий
    with open(os.path.join(templates_dir, 'categories.html'), 'w') as f:
        f.write('''{% extends 'base.html' %}

{% block title %}DeepSeek Bot - Категории{% endblock %}

{% block content %}
<h1>Категории</h1>
<p class="lead">Список категорий документов в базе знаний.</p>

<div class="mb-3">
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal">Добавить категорию</button>
</div>

{% if categories %}
<div class="row">
    {% for category in categories %}
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title">{{ category.name }}</h5>
                <p class="card-text">{{ category.description or 'Без описания' }}</p>
            </div>
            <div class="card-footer">
                <a href="{{ url_for('category_documents', category_id=category.id) }}" class="btn btn-sm btn-primary">Просмотреть документы</a>
            </div>
        </div>
    </div>
    {% endfor %}
</div>
{% else %}
<div class="alert alert-info">
    В базе данных нет категорий. Нажмите кнопку "Добавить категорию", чтобы создать новую.
</div>
{% endif %}

<!-- Модальное окно добавления категории -->
<div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addCategoryModalLabel">Добавление категории</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="{{ url_for('add_category') }}" method="post">
                <input type="hidden" name="csrf_token" value="{{ csrf_token() }}">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="name" class="form-label">Название категории:</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Описание:</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="parent_id" class="form-label">Родительская категория:</label>
                        <select class="form-select" id="parent_id" name="parent_id">
                            <option value="">Нет родительской категории</option>
                            {% for category in categories %}
                            <option value="{{ category.id }}">{{ category.name }}</option>
                            {% endfor %}
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                    <button type="submit" class="btn btn-primary">Добавить</button>
                </div>
            </form>
        </div>
    </div>
</div>
{% endblock %}''')
    
    # Создаем шаблон страницы истории запросов
    with open(os.path.join(templates_dir, 'history.html'), 'w') as f:
        f.write('''{% extends 'base.html' %}

{% block title %}DeepSeek Bot - История запросов{% endblock %}

{% block content %}
<h1>История запросов</h1>
<p class="lead">История ваших запросов и полученных ответов.</p>

{% if history %}
<div class="list-group">
    {% for item in history %}
    <div class="history-item">
        <div class="d-flex w-100 justify-content-between">
            <h5 class="mb-1">{{ item.query_text }}</h5>
            <small>{{ item.timestamp }}</small>
        </div>
        <p class="mb-1">{{ item.response_text }}</p>
        {% if item.relevant_document_ids %}
        <small>
            Источники:
            {% for doc_id in item.relevant_document_ids %}
            <a href="{{ url_for('document', document_id=doc_id) }}">Документ #{{ doc_id }}</a>{% if not loop.last %}, {% endif %}
            {% endfor %}
        </small>
        {% endif %}
    </div>
    {% endfor %}
</div>
{% else %}
<div class="alert alert-info">
    У вас пока нет истории запросов. <a href="{{ url_for('query') }}">Задайте вопрос боту</a>, чтобы начать.
</div>
{% endif %}
{% endblock %}''')
    
    # Создаем шаблоны страниц ошибок
    with open(os.path.join(templates_dir, '404.html'), 'w') as f:
        f.write('''{% extends 'base.html' %}

{% block title %}DeepSeek Bot - Страница не найдена{% endblock %}

{% block content %}
<div class="text-center">
    <h1 class="display-1">404</h1>
    <p class="lead">Страница не найдена</p>
    <p>Запрашиваемая страница не существует или была перемещена.</p>
    <a href="{{ url_for('index') }}" class="btn btn-primary">Вернуться на главную</a>
</div>
{% endblock %}''')
    
    with open(os.path.join(templates_dir, '500.html'), 'w') as f:
        f.write('''{% extends 'base.html' %}

{% block title %}DeepSeek Bot - Ошибка сервера{% endblock %}

{% block content %}
<div class="text-center">
    <h1 class="display-1">500</h1>
    <p class="lead">Внутренняя ошибка сервера</p>
    <p>Произошла ошибка при обработке вашего запроса. Пожалуйста, попробуйте позже.</p>
    <a href="{{ url_for('index') }}" class="btn btn-primary">Вернуться на главную</a>
</div>
{% endblock %}''')
