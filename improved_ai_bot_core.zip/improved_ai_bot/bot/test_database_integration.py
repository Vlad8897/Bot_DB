#!/usr/bin/env python3
"""
Скрипт для тестирования интеграции с базой данных.
Проверяет основные операции CRUD с базой данных.
"""

import os
import sys
import json
import logging
from datetime import datetime

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Устанавливаем переменную окружения для использования SQLite
os.environ['DB_TYPE'] = 'sqlite'

# Импортируем модули проекта
from database.db_manager import DatabaseManager
from database.models import Document, Category, Query

def test_database_operations():
    """Тестирует основные операции с базой данных."""
    try:
        # Создаем экземпляр менеджера базы данных
        db_manager = DatabaseManager()
        logger.info("Менеджер базы данных успешно инициализирован")
        
        # Тест 1: Добавление документа
        logger.info("Тест 1: Добавление документа")
        test_doc = db_manager.add_document(
            title="Тестовый документ",
            content="Это тестовый документ для проверки работы базы данных",
            metadata={"source": "test", "author": "bot"},
            source_type="test",
            category="test"
        )
        logger.info(f"Документ успешно добавлен с ID: {test_doc.id}")
        
        # Тест 2: Получение документа
        logger.info("Тест 2: Получение документа")
        retrieved_doc = db_manager.get_document(test_doc.id)
        if retrieved_doc:
            logger.info(f"Документ успешно получен: {retrieved_doc.title}")
        else:
            logger.error("Не удалось получить документ")
            return False
        
        # Тест 3: Обновление документа
        logger.info("Тест 3: Обновление документа")
        update_result = db_manager.update_document(
            document_id=test_doc.id,
            title="Обновленный тестовый документ",
            content="Это обновленный тестовый документ"
        )
        if update_result:
            logger.info("Документ успешно обновлен")
        else:
            logger.error("Не удалось обновить документ")
            return False
        
        # Проверяем обновление
        updated_doc = db_manager.get_document(test_doc.id)
        if updated_doc.title == "Обновленный тестовый документ":
            logger.info("Обновление документа подтверждено")
        else:
            logger.error("Обновление документа не подтверждено")
            return False
        
        # Тест 4: Добавление категории
        logger.info("Тест 4: Добавление категории")
        test_category = db_manager.add_category(
            name="Тестовая категория",
            description="Это тестовая категория для проверки работы базы данных"
        )
        logger.info(f"Категория успешно добавлена с ID: {test_category.id}")
        
        # Тест 5: Добавление документа в категорию
        logger.info("Тест 5: Добавление документа в категорию")
        add_to_category_result = db_manager.add_document_to_category(
            document_id=test_doc.id,
            category_id=test_category.id
        )
        if add_to_category_result:
            logger.info("Документ успешно добавлен в категорию")
        else:
            logger.error("Не удалось добавить документ в категорию")
            return False
        
        # Тест 6: Получение документов по категории
        logger.info("Тест 6: Получение документов по категории")
        docs_in_category = db_manager.get_documents_by_category(test_category.id)
        if docs_in_category and len(docs_in_category) > 0:
            logger.info(f"Получено документов в категории: {len(docs_in_category)}")
        else:
            logger.error("Не удалось получить документы по категории")
            return False
        
        # Тест 7: Поиск документов по ключевому слову
        logger.info("Тест 7: Поиск документов по ключевому слову")
        search_results = db_manager.search_documents_by_keyword("тестовый")
        if search_results and len(search_results) > 0:
            logger.info(f"Найдено документов по ключевому слову: {len(search_results)}")
        else:
            logger.error("Не удалось найти документы по ключевому слову")
            return False
        
        # Тест 8: Добавление запроса
        logger.info("Тест 8: Добавление запроса")
        test_query = db_manager.add_query(
            query_text="Тестовый запрос",
            user_id="test_user",
            session_id="test_session",
            response_text="Ответ на тестовый запрос",
            relevant_document_ids=[test_doc.id],
            metadata={"source": "test"}
        )
        logger.info(f"Запрос успешно добавлен с ID: {test_query.id}")
        
        # Тест 9: Получение истории запросов
        logger.info("Тест 9: Получение истории запросов")
        query_history = db_manager.get_query_history("test_session")
        if query_history and len(query_history) > 0:
            logger.info(f"Получено запросов из истории: {len(query_history)}")
        else:
            logger.error("Не удалось получить историю запросов")
            return False
        
        # Тест 10: Удаление документа
        logger.info("Тест 10: Удаление документа")
        delete_result = db_manager.delete_document(test_doc.id)
        if delete_result:
            logger.info("Документ успешно удален")
        else:
            logger.error("Не удалось удалить документ")
            return False
        
        # Проверяем удаление
        deleted_doc = db_manager.get_document(test_doc.id)
        if deleted_doc is None:
            logger.info("Удаление документа подтверждено")
        else:
            logger.error("Удаление документа не подтверждено")
            return False
        
        logger.info("Все тесты интеграции с базой данных успешно пройдены!")
        return True
    
    except Exception as e:
        logger.error(f"Ошибка при тестировании базы данных: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return False

if __name__ == "__main__":
    success = test_database_operations()
    if success:
        logger.info("Тестирование интеграции с базой данных завершено успешно")
        sys.exit(0)
    else:
        logger.error("Тестирование интеграции с базой данных завершено с ошибками")
        sys.exit(1)