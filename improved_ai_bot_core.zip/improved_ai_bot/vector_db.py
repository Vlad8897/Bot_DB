"""
Утилиты для работы с векторной базой данных PostgreSQL.
Включает функции для создания и поиска векторных представлений.
"""

import numpy as np
from sqlalchemy import text
from sqlalchemy.orm import Session
import logging
from typing import List, Dict, Any, Optional, Tuple, Union
import json

from ..models.base import db_session
from ..models.models import Document, DocumentChunk, AudioFile, AudioSegment, UserQuery

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class VectorDBManager:
    """Класс для управления векторной базой данных."""
    
    def __init__(self, embedding_dimension: int = 1536):
        """
        Инициализация менеджера векторной базы данных.
        
        Args:
            embedding_dimension: Размерность векторных представлений (по умолчанию 1536 для OpenAI embeddings)
        """
        self.embedding_dimension = embedding_dimension
        self.db = db_session()
    
    def close(self):
        """Закрытие соединения с базой данных."""
        self.db.close()
    
    def create_vector_index(self, table_name: str, column_name: str, index_name: str = None) -> bool:
        """
        Создание индекса для векторного столбца.
        
        Args:
            table_name: Имя таблицы
            column_name: Имя столбца с векторами
            index_name: Имя индекса (опционально)
            
        Returns:
            bool: True, если индекс успешно создан, иначе False
        """
        if index_name is None:
            index_name = f"idx_{table_name}_{column_name}"
        
        try:
            # Создание индекса с использованием IVFFlat для эффективного поиска
            query = text(f"""
            CREATE INDEX IF NOT EXISTS {index_name} 
            ON {table_name} USING ivfflat ({column_name} vector_cosine_ops)
            WITH (lists = 100);
            """)
            
            self.db.execute(query)
            self.db.commit()
            logger.info(f"Индекс {index_name} успешно создан для таблицы {table_name}")
            return True
        except Exception as e:
            self.db.rollback()
            logger.error(f"Ошибка при создании индекса: {e}")
            return False
    
    def store_document_embedding(self, document_id: int, embedding: List[float]) -> bool:
        """
        Сохранение векторного представления документа.
        
        Args:
            document_id: ID документа
            embedding: Векторное представление
            
        Returns:
            bool: True, если успешно сохранено, иначе False
        """
        try:
            document = self.db.query(Document).filter(Document.id == document_id).first()
            if not document:
                logger.error(f"Документ с ID {document_id} не найден")
                return False
            
            document.vector_embedding = embedding
            self.db.commit()
            logger.info(f"Векторное представление для документа {document_id} успешно сохранено")
            return True
        except Exception as e:
            self.db.rollback()
            logger.error(f"Ошибка при сохранении векторного представления документа: {e}")
            return False
    
    def store_document_chunk_embedding(self, chunk_id: int, embedding: List[float]) -> bool:
        """
        Сохранение векторного представления фрагмента документа.
        
        Args:
            chunk_id: ID фрагмента
            embedding: Векторное представление
            
        Returns:
            bool: True, если успешно сохранено, иначе False
        """
        try:
            chunk = self.db.query(DocumentChunk).filter(DocumentChunk.id == chunk_id).first()
            if not chunk:
                logger.error(f"Фрагмент документа с ID {chunk_id} не найден")
                return False
            
            chunk.vector_embedding = embedding
            self.db.commit()
            logger.info(f"Векторное представление для фрагмента {chunk_id} успешно сохранено")
            return True
        except Exception as e:
            self.db.rollback()
            logger.error(f"Ошибка при сохранении векторного представления фрагмента: {e}")
            return False
    
    def store_audio_embedding(self, audio_id: int, embedding: List[float]) -> bool:
        """
        Сохранение векторного представления аудиофайла.
        
        Args:
            audio_id: ID аудиофайла
            embedding: Векторное представление
            
        Returns:
            bool: True, если успешно сохранено, иначе False
        """
        try:
            audio = self.db.query(AudioFile).filter(AudioFile.id == audio_id).first()
            if not audio:
                logger.error(f"Аудиофайл с ID {audio_id} не найден")
                return False
            
            audio.vector_embedding = embedding
            self.db.commit()
            logger.info(f"Векторное представление для аудиофайла {audio_id} успешно сохранено")
            return True
        except Exception as e:
            self.db.rollback()
            logger.error(f"Ошибка при сохранении векторного представления аудиофайла: {e}")
            return False
    
    def store_audio_segment_embedding(self, segment_id: int, embedding: List[float]) -> bool:
        """
        Сохранение векторного представления сегмента аудиофайла.
        
        Args:
            segment_id: ID сегмента
            embedding: Векторное представление
            
        Returns:
            bool: True, если успешно сохранено, иначе False
        """
        try:
            segment = self.db.query(AudioSegment).filter(AudioSegment.id == segment_id).first()
            if not segment:
                logger.error(f"Сегмент аудиофайла с ID {segment_id} не найден")
                return False
            
            segment.vector_embedding = embedding
            self.db.commit()
            logger.info(f"Векторное представление для сегмента {segment_id} успешно сохранено")
            return True
        except Exception as e:
            self.db.rollback()
            logger.error(f"Ошибка при сохранении векторного представления сегмента: {e}")
            return False
    
    def search_similar_documents(self, query_embedding: List[float], limit: int = 5, threshold: float = 0.7) -> List[Dict[str, Any]]:
        """
        Поиск документов, похожих на запрос.
        
        Args:
            query_embedding: Векторное представление запроса
            limit: Максимальное количество результатов
            threshold: Минимальный порог сходства (от 0 до 1)
            
        Returns:
            List[Dict]: Список документов с их метаданными и оценкой сходства
        """
        try:
            # Использование косинусного сходства для поиска похожих документов
            query = text("""
            SELECT d.id, d.title, d.content, d.file_path, d.file_type, d.metadata,
                   1 - (d.vector_embedding <=> :query_vector) as similarity
            FROM documents d
            WHERE 1 - (d.vector_embedding <=> :query_vector) > :threshold
            ORDER BY similarity DESC
            LIMIT :limit
            """)
            
            result = self.db.execute(
                query,
                {
                    "query_vector": query_embedding,
                    "threshold": threshold,
                    "limit": limit
                }
            )
            
            documents = []
            for row in result:
                doc = {
                    "id": row.id,
                    "title": row.title,
                    "content": row.content,
                    "file_path": row.file_path,
                    "file_type": row.file_type,
                    "metadata": row.metadata,
                    "similarity": float(row.similarity)
                }
                documents.append(doc)
            
            return documents
        except Exception as e:
            logger.error(f"Ошибка при поиске похожих документов: {e}")
            return []
    
    def search_similar_document_chunks(self, query_embedding: List[float], limit: int = 10, threshold: float = 0.7) -> List[Dict[str, Any]]:
        """
        Поиск фрагментов документов, похожих на запрос.
        
        Args:
            query_embedding: Векторное представление запроса
            limit: Максимальное количество результатов
            threshold: Минимальный порог сходства (от 0 до 1)
            
        Returns:
            List[Dict]: Список фрагментов с их метаданными и оценкой сходства
        """
        try:
            # Использование косинусного сходства для поиска похожих фрагментов
            query = text("""
            SELECT c.id, c.document_id, c.content, c.chunk_index, c.metadata,
                   d.title as document_title, d.file_path,
                   1 - (c.vector_embedding <=> :query_vector) as similarity
            FROM document_chunks c
            JOIN documents d ON c.document_id = d.id
            WHERE 1 - (c.vector_embedding <=> :query_vector) > :threshold
            ORDER BY similarity DESC
            LIMIT :limit
            """)
            
            result = self.db.execute(
                query,
                {
                    "query_vector": query_embedding,
                    "threshold": threshold,
                    "limit": limit
                }
            )
            
            chunks = []
            for row in result:
                chunk = {
                    "id": row.id,
                    "document_id": row.document_id,
                    "document_title": row.document_title,
                    "content": row.content,
                    "chunk_index": row.chunk_index,
                    "file_path": row.file_path,
                    "metadata": row.metadata,
                    "similarity": float(row.similarity)
                }
                chunks.append(chunk)
            
            return chunks
        except Exception as e:
            logger.error(f"Ошибка при поиске похожих фрагментов документов: {e}")
            return []
    
    def search_similar_audio(self, query_embedding: List[float], limit: int = 5, threshold: float = 0.7) -> List[Dict[str, Any]]:
        """
        Поиск аудиофайлов, похожих на запрос.
        
        Args:
            query_embedding: Векторное представление запроса
            limit: Максимальное количество результатов
            threshold: Минимальный порог сходства (от 0 до 1)
            
        Returns:
            List[Dict]: Список аудиофайлов с их метаданными и оценкой сходства
        """
        try:
            # Использование косинусного сходства для поиска похожих аудиофайлов
            query = text("""
            SELECT a.id, a.title, a.file_path, a.duration, a.transcription, a.metadata,
                   1 - (a.vector_embedding <=> :query_vector) as similarity
            FROM audio_files a
            WHERE 1 - (a.vector_embedding <=> :query_vector) > :threshold
            ORDER BY similarity DESC
            LIMIT :limit
            """)
            
            result = self.db.execute(
                query,
                {
                    "query_vector": query_embedding,
                    "threshold": threshold,
                    "limit": limit
                }
            )
            
            audio_files = []
            for row in result:
                audio = {
                    "id": row.id,
                    "title": row.title,
                    "file_path": row.file_path,
                    "duration": row.duration,
                    "transcription": row.transcription,
                    "metadata": row.metadata,
                    "similarity": float(row.similarity)
                }
                audio_files.append(audio)
            
            return audio_files
        except Exception as e:
            logger.error(f"Ошибка при поиске похожих аудиофайлов: {e}")
            return []
    
    def hybrid_search(self, query_text: str, query_embedding: List[float], limit: int = 10) -> List[Dict[str, Any]]:
        """
        Гибридный поиск, сочетающий текстовый поиск и векторное сходство.
        
        Args:
            query_text: Текстовый запрос
            query_embedding: Векторное представление запроса
            limit: Максимальное количество результатов
            
        Returns:
            List[Dict]: Список результатов с их метаданными и оценкой релевантности
        """
        try:
            # Использование комбинации полнотекстового поиска и векторного сходства
            query = text("""
            WITH text_search AS (
                SELECT 
                    d.id,
                    d.title,
                    d.content,
                    d.file_path,
                    d.file_type,
                    d.metadata,
                    ts_rank_cd(to_tsvector('russian', d.title || ' ' || d.content), plainto_tsquery('russian', :query_text)) as text_rank
                FROM documents d
                WHERE to_tsvector('russian', d.title || ' ' || d.content) @@ plainto_tsquery('russian', :query_text)
            ),
            vector_search AS (
                SELECT 
                    d.id,
                    1 - (d.vector_embedding <=> :query_vector) as vector_similarity
                FROM documents d
            )
            SELECT 
                ts.id,
                ts.title,
                ts.content,
                ts.file_path,
                ts.file_type,
                ts.metadata,
                ts.text_rank,
                vs.vector_similarity,
                (ts.text_rank * 0.4 + vs.vector_similarity * 0.6) as combined_score
            FROM text_search ts
            JOIN vector_search vs ON ts.id = vs.id
            ORDER BY combined_score DESC
            LIMIT :limit
            """)
            
            result = self.db.execute(
                query,
                {
                    "query_text": query_text,
                    "query_vector": query_embedding,
                    "limit": limit
                }
            )
            
            results = []
            for row in result:
                item = {
                    "id": row.id,
                    "title": row.title,
                    "content": row.content,
                    "file_path": row.file_path,
                    "file_type": row.file_type,
                    "metadata": row.metadata,
                    "text_rank": float(row.text_rank),
                    "vector_similarity": float(row.vector_similarity),
                    "combined_score": float(row.combined_score)
                }
                results.append(item)
            
            return results
        except Exception as e:
            logger.error(f"Ошибка при выполнении гибридного поиска: {e}")
            return []
    
    def update_vector_indices(self) -> bool:
        """
        Обновление всех векторных индексов в базе данных.
        
        Returns:
            bool: True, если все индексы успешно обновлены, иначе False
        """
        try:
            # Обновление индексов для всех таблиц с векторными представлениями
            tables = [
                ("documents", "vector_embedding", "idx_documents_vector"),
                ("document_chunks", "vector_embedding", "idx_document_chunks_vector"),
                ("audio_files", "vector_embedding", "idx_audio_files_vector"),
                ("audio_segments", "vector_embedding", "idx_audio_segments_vector"),
                ("user_queries", "vector_embedding", "idx_user_queries_vector")
            ]
            
            for table, column, index_name in tables:
                self.create_vector_index(table, column, index_name)
            
            logger.info("<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>