#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Модуль настройки векторной базы данных PostgreSQL для AI бота.
Включает создание таблиц, индексов и функций для работы с векторными данными.
"""

import os
import sys
import logging
import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, ForeignKey, Float, Boolean, LargeBinary
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy.dialects.postgresql import JSONB, ARRAY
from sqlalchemy.sql import func
import numpy as np
from datetime import datetime

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# Параметры подключения к PostgreSQL
DB_HOST = os.environ.get('DB_HOST', 'localhost')
DB_PORT = os.environ.get('DB_PORT', '5432')
DB_USER = os.environ.get('DB_USER', 'postgres')
DB_PASSWORD = os.environ.get('DB_PASSWORD', 'postgres')
DB_NAME = os.environ.get('DB_NAME', 'ai_bot_db')

# Строка подключения к базе данных
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# Создание базового класса для моделей
Base = declarative_base()

class Document(Base):
    """Модель для хранения документов"""
    __tablename__ = 'documents'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    content = Column(Text, nullable=False)
    content_vector = Column(ARRAY(Float), nullable=True)  # Векторное представление контента
    file_path = Column(String(255), nullable=True)
    file_type = Column(String(50), nullable=True)
    category = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    metadata = Column(JSONB, nullable=True)
    
    # Отношения
    chunks = relationship("DocumentChunk", back_populates="document", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Document(id={self.id}, title='{self.title}')>"

class DocumentChunk(Base):
    """Модель для хранения фрагментов документов"""
    __tablename__ = 'document_chunks'
    
    id = Column(Integer, primary_key=True)
    document_id = Column(Integer, ForeignKey('documents.id'), nullable=False)
    content = Column(Text, nullable=False)
    content_vector = Column(ARRAY(Float), nullable=True)  # Векторное представление фрагмента
    chunk_index = Column(Integer, nullable=False)
    metadata = Column(JSONB, nullable=True)
    
    # Отношения
    document = relationship("Document", back_populates="chunks")
    
    def __repr__(self):
        return f"<DocumentChunk(id={self.id}, document_id={self.document_id}, chunk_index={self.chunk_index})>"

class AudioFile(Base):
    """Модель для хранения аудиофайлов"""
    __tablename__ = 'audio_files'
    
    id = Column(Integer, primary_key=True)
    file_name = Column(String(255), nullable=False)
    file_path = Column(String(255), nullable=False)
    transcription = Column(Text, nullable=True)  # Транскрипция аудио в текст
    transcription_vector = Column(ARRAY(Float), nullable=True)  # Векторное представление транскрипции
    duration = Column(Float, nullable=True)  # Длительность в секундах
    created_at = Column(DateTime, default=func.now())
    metadata = Column(JSONB, nullable=True)
    
    def __repr__(self):
        return f"<AudioFile(id={self.id}, file_name='{self.file_name}')>"

class UserQuery(Base):
    """Модель для хранения запросов пользователей"""
    __tablename__ = 'user_queries'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(String(100), nullable=True)
    query_text = Column(Text, nullable=True)
    query_vector = Column(ARRAY(Float), nullable=True)  # Векторное представление запроса
    query_audio_id = Column(Integer, ForeignKey('audio_files.id'), nullable=True)
    response_text = Column(Text, nullable=True)
    created_at = Column(DateTime, default=func.now())
    metadata = Column(JSONB, nullable=True)
    
    # Отношения
    relevant_documents = relationship("QueryDocumentRelevance", back_populates="query")
    
    def __repr__(self):
        return f"<UserQuery(id={self.id}, query_text='{self.query_text[:30]}...' if self.query_text and len(self.query_text) > 30 else self.query_text)>"

class QueryDocumentRelevance(Base):
    """Модель для хранения связей между запросами и релевантными документами"""
    __tablename__ = 'query_document_relevance'
    
    id = Column(Integer, primary_key=True)
    query_id = Column(Integer, ForeignKey('user_queries.id'), nullable=False)
    document_id = Column(Integer, ForeignKey('documents.id'), nullable=False)
    relevance_score = Column(Float, nullable=False)  # Оценка релевантности
    
    # Отношения
    query = relationship("UserQuery", back_populates="relevant_documents")
    
    def __repr__(self):
        return f"<QueryDocumentRelevance(query_id={self.query_id}, document_id={self.document_id}, relevance_score={self.relevance_score})>"

def create_database():
    """Создание базы данных, если она не существует"""
    try:
        # Подключение к PostgreSQL
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            user=DB_USER,
            password=DB_PASSWORD
        )
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = conn.cursor()
        
        # Проверка существования базы данных
        cursor.execute(f"SELECT 1 FROM pg_catalog.pg_database WHERE datname = '{DB_NAME}'")
        exists = cursor.fetchone()
        
        if not exists:
            # Создание базы данных
            cursor.execute(f"CREATE DATABASE {DB_NAME}")
            logger.info(f"База данных {DB_NAME} успешно создана")
        else:
            logger.info(f"База данных {DB_NAME} уже существует")
        
        cursor.close()
        conn.close()
        
    except Exception as e:
        logger.error(f"Ошибка при создании базы данных: {e}")
        sys.exit(1)

def create_pgvector_extension():
    """Создание расширения pgvector для работы с векторами"""
    try:
        # Подключение к созданной базе данных
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = conn.cursor()
        
        # Создание расширения pgvector
        cursor.execute("CREATE EXTENSION IF NOT EXISTS vector")
        logger.info("Расширение pgvector успешно создано")
        
        cursor.close()
        conn.close()
        
    except Exception as e:
        logger.error(f"Ошибка при создании расширения pgvector: {e}")
        logger.warning("Для работы с векторами необходимо установить расширение pgvector в PostgreSQL")

def create_tables():
    """Создание таблиц в базе данных"""
    try:
        # Создание движка SQLAlchemy
        engine = create_engine(DATABASE_URL)
        
        # Создание таблиц
        Base.metadata.create_all(engine)
        logger.info("Таблицы успешно созданы")
        
        # Создание сессии
        Session = sessionmaker(bind=engine)
        session = Session()
        
        # Создание индексов для векторного поиска
        session.execute("""
        CREATE INDEX IF NOT EXISTS document_content_vector_idx 
        ON documents USING ivfflat (content_vector vector_cosine_ops)
        WITH (lists = 100);
        """)
        
        session.execute("""
        CREATE INDEX IF NOT EXISTS document_chunk_content_vector_idx 
        ON document_chunks USING ivfflat (content_vector vector_cosine_ops)
        WITH (lists = 100);
        """)
        
        session.execute("""
        CREATE INDEX IF NOT EXISTS audio_transcription_vector_idx 
        ON audio_files USING ivfflat (transcription_vector vector_cosine_ops)
        WITH (lists = 100);
        """)
        
        session.execute("""
        CREATE INDEX IF NOT EXISTS user_query_vector_idx 
        ON user_queries USING ivfflat (query_vector vector_cosine_ops)
        WITH (lists = 100);
        """)
        
        session.commit()
        logger.info("Индексы для векторного поиска успешно созданы")
        
        session.close()
        
    except Exception as e:
        logger.error(f"Ошибка при создании таблиц: {e}")

def main():
    """Основная функция для настройки базы данных"""
    logger.info("Начало настройки векторной базы данных PostgreSQL")
    
    # Создание базы данных
    create_database()
    
    # Создание расширения pgvector
    create_pgvector_extension()
    
    # Создание таблиц и индексов
    create_tables()
    
    logger.info("Настройка векторной базы данных PostgreSQL успешно завершена")

if __name__ == "__main__":
    main()
