#!/usr/bin/env python3
"""
Модуль для настройки тестовой базы данных SQLite для бота на основе DeepSeek.
Создает локальную базу данных SQLite для тестирования функциональности бота.
"""

import os
import logging
from sqlalchemy import create_engine
from database.models import Base

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def setup_test_database():
    """Создает тестовую базу данных SQLite."""
    # Путь к файлу базы данных
    db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_database.db')
    
    # Строка подключения к базе данных SQLite
    database_url = f"sqlite:///{db_path}"
    
    # Создание движка SQLAlchemy
    engine = create_engine(database_url)
    
    try:
        # Создание таблиц
        Base.metadata.create_all(engine)
        logger.info(f"Тестовая база данных успешно создана по пути: {db_path}")
        logger.info(f"Строка подключения: {database_url}")
        return database_url
    except Exception as e:
        logger.error(f"Ошибка при создании тестовой базы данных: {e}")
        return None

if __name__ == "__main__":
    setup_test_database()
