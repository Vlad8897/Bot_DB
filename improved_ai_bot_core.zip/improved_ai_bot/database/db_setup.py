#!/usr/bin/env python3
import os
import sys
import subprocess
import time
from sqlalchemy import create_engine, Column, Integer, String, Float, Text, ForeignKey, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
import datetime
from dotenv import load_dotenv

# Загрузка переменных окружения
load_dotenv()

# Параметры подключения к базе данных
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "deepseek_bot")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "postgres")

# Функция для выполнения команд с обработкой ошибок
def run_command(command):
    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            shell=True
        )
        stdout, stderr = process.communicate()
        
        # Безопасное декодирование с игнорированием ошибок
        try:
            stdout_str = stdout.decode('utf-8', errors='ignore')
        except:
            stdout_str = str(stdout)
            
        try:
            stderr_str = stderr.decode('utf-8', errors='ignore')
        except:
            stderr_str = str(stderr)
            
        return process.returncode, stdout_str, stderr_str
    except Exception as e:
        return 1, "", str(e)

# Функция для создания базы данных
def create_database():
    print("Создание базы данных deepseek_bot...")
    
    # Проверка существования базы данных
    check_cmd = f'psql -U {DB_USER} -h {DB_HOST} -p {DB_PORT} -c "SELECT 1 FROM pg_database WHERE datname=\'{DB_NAME}\'"'
    returncode, stdout, stderr = run_command(check_cmd)
    
    if returncode != 0:
        print(f"Ошибка при проверке базы данных: {stderr}")
        return False
    
    # Если база данных не существует, создаем ее
    if "1 row" not in stdout:
        create_cmd = f'psql -U {DB_USER} -h {DB_HOST} -p {DB_PORT} -c "CREATE DATABASE {DB_NAME}"'
        returncode, stdout, stderr = run_command(create_cmd)
        
        if returncode != 0:
            print(f"Ошибка при создании базы данных: {stderr}")
            return False
        
        print(f"База данных {DB_NAME} успешно создана.")
    else:
        print(f"База данных {DB_NAME} уже существует.")
    
    return True

# Создание строки подключения
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# Создание движка SQLAlchemy
def create_engine_safe():
    try:
        return create_engine(DATABASE_URL)
    except Exception as e:
        print(f"Ошибка при создании движка SQLAlchemy: {e}")
        return None

# Импортируем модели из database.models вместо определения их здесь
try:
    from database.models import Base, Document, Chunk, Category, Query, Source, DataSource, User
    print("Успешно импортированы модели из database.models")
except ImportError as e:
    print(f"Ошибка при импорте моделей: {e}")
    print("Используем локальные определения моделей")
    
    # Создание базового класса для моделей
    Base = declarative_base()
    
    # Определение моделей
    class Document(Base):
        __tablename__ = 'documents'
        
        id = Column(Integer, primary_key=True)
        title = Column(String(255), nullable=False)
        content = Column(Text, nullable=False)
        category = Column(String(100))
        created_at = Column(DateTime, default=datetime.datetime.utcnow)
        updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
        
        fragments = relationship("Fragment", back_populates="document", cascade="all, delete-orphan")
        sources = relationship("Source", back_populates="document", cascade="all, delete-orphan")
    
    class Fragment(Base):
        __tablename__ = 'fragments'
        
        id = Column(Integer, primary_key=True)
        document_id = Column(Integer, ForeignKey('documents.id'))
        content = Column(Text, nullable=False)
        embedding = Column(Text)  # Хранение векторного представления в виде строки
        
        document = relationship("Document", back_populates="fragments")
    
    class Query(Base):
        __tablename__ = 'queries'
        
        id = Column(Integer, primary_key=True)
        user_id = Column(String(100))
        session_id = Column(String(100))
        query_text = Column(Text, nullable=False)
        response = Column(Text, nullable=False)
        timestamp = Column(DateTime, default=datetime.datetime.utcnow)
        
        sources = relationship("Source", back_populates="query", cascade="all, delete-orphan")
    
    class Source(Base):
        __tablename__ = 'sources'
        
        id = Column(Integer, primary_key=True)
        query_id = Column(Integer, ForeignKey('queries.id'))
        document_id = Column(Integer, ForeignKey('documents.id'))
        relevance = Column(Float)
        
        query = relationship("Query", back_populates="sources")
        document = relationship("Document", back_populates="sources")
    
    class Category(Base):
        __tablename__ = 'categories'
        
        id = Column(Integer, primary_key=True)
        name = Column(String(100), nullable=False, unique=True)
        description = Column(Text)
    
    class DataSource(Base):
        __tablename__ = 'data_sources'
        
        id = Column(Integer, primary_key=True)
        name = Column(String(100), nullable=False)
        type = Column(String(50), nullable=False)  # file, api, database
        connection_info = Column(Text)
        last_sync = Column(DateTime)

# Создание таблиц в базе данных
def setup_database():
    engine = create_engine_safe()
    if not engine:
        return False
    
    try:
        Base.metadata.create_all(engine)
        print("Таблицы успешно созданы в базе данных.")
        return True
    except Exception as e:
        print(f"Ошибка при создании таблиц: {e}")
        return False

# Добавление тестовых данных
def add_test_data():
    engine = create_engine_safe()
    if not engine:
        return False
    
    # Создание сессии
    Session = sessionmaker(bind=engine)
    session = Session()
    
    try:
        # Проверка, есть ли уже данные в таблице documents
        doc_count = session.query(Document).count()
        if doc_count > 0:
            print(f"В базе данных уже есть {doc_count} документов. Пропускаем добавление тестовых данных.")
            return True
        
        # Добавление категорий
        categories = [
            Category(name="database", description="Информация о базах данных"),
            Category(name="ai", description="Информация об искусственном интеллекте"),
            Category(name="features", description="Функциональные возможности")
        ]
        session.add_all(categories)
        
        # Добавление тестовых документов
        documents = [
            Document(
                title="Архитектура базы данных",
                content="PostgreSQL с расширением pg_vector используется для эффективного хранения и поиска векторных представлений текстов.",
                category="database"
            ),
            Document(
                title="О модели DeepSeek",
                content="DeepSeek предоставляет API для генерации текста, векторных представлений и семантического поиска.",
                category="ai"
            ),
            Document(
                title="Возможности бота",
                content="Бот может отвечать на вопросы, основываясь на информации из базы данных, анализировать тексты и помогать в поиске информации.",
                category="features"
            )
        ]
        session.add_all(documents)
        
        # Добавление источников данных
        data_sources = [
            DataSource(
                name="Локальные файлы",
                type="file",
                connection_info="D:/data/documents",
                last_sync=datetime.datetime.utcnow()
            ),
            DataSource(
                name="API DeepSeek",
                type="api",
                connection_info="https://api.deepseek.com",
                last_sync=datetime.datetime.utcnow() 
            )
        ]
        session.add_all(data_sources)
        
        session.commit()
        print("Тестовые данные успешно добавлены.")
        return True
    except Exception as e:
        session.rollback()
        print(f"Ошибка при добавлении тестовых данных: {e}")
        return False
    finally:
        session.close()

# Основная функция
def main():
    print("Начало настройки базы данных для бота на основе DeepSeek...")
    
    # Шаг 1: Создание базы данных
    if not create_database():
        print("Не удалось создать базу данных. Проверьте, запущен ли PostgreSQL и доступен ли пользователь postgres.")
        
        # Альтернативный вариант: использовать SQLite
        use_sqlite = input("Хотите использовать SQLite вместо PostgreSQL? (да/нет): ").lower()
        if use_sqlite == "да":
            print("Переключение на SQLite...")
            # Здесь можно добавить код для настройки SQLite
            return
        else:
            print("Настройка прервана.")
            return
    
    # Шаг 2: Создание таблиц
    if not setup_database():
        print("Не удалось создать таблицы в базе данных.")
        return
    
    # Шаг 3: Добавление тестовых данных
    if not add_test_data():
        print("Не удалось добавить тестовые данные.")
        return
    
    print("Настройка базы данных успешно завершена!")
    print("Теперь вы можете запустить бота с помощью команды: python console_interface.py")

if __name__ == "__main__":
    main()
