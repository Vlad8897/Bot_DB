import { D1Database } from '@cloudflare/workers-types';

export interface Document {
  id?: number;
  title: string;
  content: string;
  meta_data?: Record<string, any>;
  source_type: string;
  category_id?: number;
  embedding?: number[];
  created_at?: string;
  updated_at?: string;
}

export interface Category {
  id?: number;
  name: string;
  parent_id?: number;
  created_at?: string;
  updated_at?: string;
}

export interface QueryHistory {
  id?: number;
  user_id: string;
  query: string;
  response: string;
  documents?: number[];
  timestamp?: string;
}

export class DatabaseService {
  private db: D1Database;

  constructor(db: D1Database) {
    this.db = db;
  }

  // Документы
  async getDocuments(): Promise<Document[]> {
    const { results } = await this.db.prepare('SELECT * FROM documents ORDER BY created_at DESC').all();
    return results as Document[];
  }

  async getDocumentById(id: number): Promise<Document | null> {
    const result = await this.db.prepare('SELECT * FROM documents WHERE id = ?').bind(id).first();
    return result as Document | null;
  }

  async getDocumentsByCategory(categoryId: number): Promise<Document[]> {
    const { results } = await this.db.prepare('SELECT * FROM documents WHERE category_id = ? ORDER BY created_at DESC')
      .bind(categoryId).all();
    return results as Document[];
  }

  async createDocument(document: Document): Promise<number> {
    const { title, content, meta_data, source_type, category_id } = document;
    const metaDataJson = meta_data ? JSON.stringify(meta_data) : null;
    
    const result = await this.db.prepare(
      'INSERT INTO documents (title, content, meta_data, source_type, category_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, datetime("now"), datetime("now"))'
    ).bind(title, content, metaDataJson, source_type, category_id).run();
    
    return result.meta.last_row_id as number;
  }

  async updateDocument(id: number, document: Partial<Document>): Promise<boolean> {
    const { title, content, meta_data, source_type, category_id } = document;
    const metaDataJson = meta_data ? JSON.stringify(meta_data) : null;
    
    const result = await this.db.prepare(
      'UPDATE documents SET title = ?, content = ?, meta_data = ?, source_type = ?, category_id = ?, updated_at = datetime("now") WHERE id = ?'
    ).bind(title, content, metaDataJson, source_type, category_id, id).run();
    
    return result.meta.changes > 0;
  }

  async deleteDocument(id: number): Promise<boolean> {
    const result = await this.db.prepare('DELETE FROM documents WHERE id = ?').bind(id).run();
    return result.meta.changes > 0;
  }

  async searchDocuments(query: string, limit: number = 10): Promise<Document[]> {
    // Простой поиск по содержимому и заголовку
    const { results } = await this.db.prepare(
      'SELECT * FROM documents WHERE title LIKE ? OR content LIKE ? ORDER BY created_at DESC LIMIT ?'
    ).bind(`%${query}%`, `%${query}%`, limit).all();
    
    return results as Document[];
  }

  // Категории
  async getCategories(): Promise<Category[]> {
    const { results } = await this.db.prepare('SELECT * FROM categories ORDER BY name').all();
    return results as Category[];
  }

  async getCategoryById(id: number): Promise<Category | null> {
    const result = await this.db.prepare('SELECT * FROM categories WHERE id = ?').bind(id).first();
    return result as Category | null;
  }

  async createCategory(category: Category): Promise<number> {
    const { name, parent_id } = category;
    
    const result = await this.db.prepare(
      'INSERT INTO categories (name, parent_id, created_at, updated_at) VALUES (?, ?, datetime("now"), datetime("now"))'
    ).bind(name, parent_id).run();
    
    return result.meta.last_row_id as number;
  }

  async updateCategory(id: number, category: Partial<Category>): Promise<boolean> {
    const { name, parent_id } = category;
    
    const result = await this.db.prepare(
      'UPDATE categories SET name = ?, parent_id = ?, updated_at = datetime("now") WHERE id = ?'
    ).bind(name, parent_id, id).run();
    
    return result.meta.changes > 0;
  }

  async deleteCategory(id: number): Promise<boolean> {
    const result = await this.db.prepare('DELETE FROM categories WHERE id = ?').bind(id).run();
    return result.meta.changes > 0;
  }

  // История запросов
  async getQueryHistory(userId: string, limit: number = 100): Promise<QueryHistory[]> {
    const { results } = await this.db.prepare(
      'SELECT * FROM query_history WHERE user_id = ? ORDER BY timestamp DESC LIMIT ?'
    ).bind(userId, limit).all();
    
    return results as QueryHistory[];
  }

  async createQueryHistory(history: QueryHistory): Promise<number> {
    const { user_id, query, response, documents } = history;
    const documentsJson = documents ? JSON.stringify(documents) : null;
    
    const result = await this.db.prepare(
      'INSERT INTO query_history (user_id, query, response, documents, timestamp) VALUES (?, ?, ?, ?, datetime("now"))'
    ).bind(user_id, query, response, documentsJson).run();
    
    return result.meta.last_row_id as number;
  }

  async deleteQueryHistory(id: number): Promise<boolean> {
    const result = await this.db.prepare('DELETE FROM query_history WHERE id = ?').bind(id).run();
    return result.meta.changes > 0;
  }
}
