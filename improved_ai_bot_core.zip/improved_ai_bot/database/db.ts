import { DatabaseService } from '@/lib/database';

declare global {
  var db: DatabaseService | undefined;
}

export function getDatabase(): DatabaseService {
  if (!global.db) {
    // @ts-ignore - D1 доступен в среде Cloudflare Workers
    const d1 = process.env.NODE_ENV === 'production' ? DB : DB.withSqlite();
    global.db = new DatabaseService(d1);
  }
  return global.db;
}
