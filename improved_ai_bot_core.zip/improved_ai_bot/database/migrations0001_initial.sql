-- Удаление существующих таблиц, если они есть
DROP TABLE IF EXISTS documents;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS query_history;

-- Создание таблицы категорий
CREATE TABLE categories (
  id SERIAL PRIMARY KEY,  -- Используйте SERIAL для автоинкремента
  name TEXT NOT NULL,
  parent_id INTEGER,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  FOREIGN KEY (parent_id) REFERENCES categories (id) ON DELETE SET NULL
);

-- Создание таблицы документов
CREATE TABLE documents (
  id SERIAL PRIMARY KEY,  -- Используйте SERIAL для автоинкремента
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  meta_data TEXT,
  source_type TEXT NOT NULL,
  category_id INTEGER,
  embedding TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL
);

-- Создание таблицы истории запросов
CREATE TABLE query_history (
  id SERIAL PRIMARY KEY,  -- Используйте SERIAL для автоинкремента
  user_id TEXT NOT NULL,
  query TEXT NOT NULL,
  response TEXT NOT NULL,
  documents TEXT,
  timestamp TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Вставка тестовых данных для категорий
INSERT INTO categories (name, parent_id, created_at, updated_at) VALUES
('Общая информация', NULL, NOW(), NOW()),
('Техническая документация', NULL, NOW(), NOW()),
('Руководства пользователя', NULL, NOW(), NOW()),
('API документация', 2, NOW(), NOW()),
('Инструкции по установке', 2, NOW(), NOW());

-- Вставка тестовых данных для документов
INSERT INTO documents (title, content, meta_data, source_type, category_id, created_at, updated_at) VALUES
('Введение в DeepSeek', 'DeepSeek - это мощный инструмент для работы с базами данных, который использует искусственный интеллект для обработки запросов на естественном языке.', '{"author": "Admin", "tags": ["introduction", "overview"]}', 'manual', 1, NOW(), NOW()),
('Установка DeepSeek на Windows', 'Подробная инструкция по установке DeepSeek на операционную систему Windows. Шаг 1: Скачайте установщик с официального сайта...', '{"author": "Admin", "os": "Windows", "version": "1.0"}', 'manual', 5, NOW(), NOW()),
('Установка DeepSeek на Linux', 'Подробная инструкция по установке DeepSeek на операционную систему Linux. Шаг 1: Используйте пакетный менеджер для установки...', '{"author": "Admin", "os": "Linux", "version": "1.0"}', 'manual', 5, NOW(), NOW()),
('API Reference', 'Документация по API DeepSeek. Включает описание всех доступных эндпоинтов и параметров.', '{"author": "Developer", "version": "1.0"}', 'manual', 4, NOW(), NOW()),
('Руководство по использованию', 'Подробное руководство по использованию DeepSeek для работы с базами данных. Включает примеры запросов и ответов.', '{"author": "Admin", "tags": ["usage", "examples"]}', 'manual', 3, NOW(), NOW());

-- Вставка тестовых данных для истории запросов
INSERT INTO query_history (user_id, query, response, documents, timestamp) VALUES
('default-user', 'Как установить DeepSeek?', 'Для установки DeepSeek следуйте инструкциям в документации по установке для вашей операционной системы.', '[2, 3]', NOW()),
('default-user', 'Что такое DeepSeek?', 'DeepSeek - это мощный инструмент для работы с базами данных, который использует искусственный интеллект для обработки запросов на естественном языке.', '[1]', NOW() - INTERVAL '1 day'),
('default-user', 'Как использовать API?', 'API DeepSeek предоставляет различные эндпоинты для взаимодействия с базой данных. Подробную информацию можно найти в API Reference.', '[4]', NOW() - INTERVAL '2 days');
