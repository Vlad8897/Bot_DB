#!/usr/bin/env python3
"""
Модуль для интеграции DeepSeek API с базой данных PostgreSQL.
Обеспечивает взаимодействие между DeepSeek и базой данных для обработки запросов.
"""

import os
import sys
import json
import logging
import numpy as np
import requests
from typing import List, Dict, Any, Optional, Tuple, Union
from dotenv import load_dotenv

# Добавляем родительскую директорию в путь для импорта
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Импортируем менеджер базы данных
from database.db_manager import DatabaseManager

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Загрузка переменных окружения
load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env'))

# Параметры DeepSeek API
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
DEEPSEEK_API_BASE_URL = os.getenv("DEEPSEEK_API_BASE_URL", "https://api.deepseek.com")
DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")

class DeepSeekIntegration:
    """Класс для интеграции DeepSeek API с базой данных."""
    
    def __init__(self, db_manager: DatabaseManager = None):
        """Инициализация интеграции DeepSeek с базой данных."""
        self.api_key = DEEPSEEK_API_KEY
        self.api_base_url = DEEPSEEK_API_BASE_URL
        self.model = DEEPSEEK_MODEL
        
        # Проверка наличия API ключа
        if not self.api_key or self.api_key == "your_api_key_here":
            logger.warning("API ключ DeepSeek не настроен. Некоторые функции будут недоступны.")
        
        # Инициализация менеджера базы данных
        self.db_manager = db_manager if db_manager else DatabaseManager()
    
    def generate_embedding(self, text: str) -> List[float]:
        """
        Генерирует векторное представление (эмбеддинг) для текста с использованием DeepSeek API.
        В случае отсутствия API ключа или ошибки, возвращает случайный вектор для тестирования.
        """
        if not self.api_key or self.api_key == "your_api_key_here":
            logger.warning("API ключ DeepSeek не настроен. Используется случайный вектор для тестирования.")
            return np.random.rand(1536).tolist()
        
        try:
            # Запрос к DeepSeek API для получения эмбеддинга
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}"
            }
            
            data = {
                "model": "deepseek-embedding",  # Модель для эмбеддингов
                "input": text
            }
            
            response = requests.post(
                f"{self.api_base_url}/embeddings",
                headers=headers,
                json=data
            )
            
            if response.status_code == 200:
                result = response.json()
                embedding = result["data"][0]["embedding"]
                return embedding
            else:
                logger.error(f"Ошибка при получении эмбеддинга: {response.status_code} - {response.text}")
                # Возвращаем случайный вектор для тестирования
                return np.random.rand(1536).tolist()
        
        except Exception as e:
            logger.error(f"Исключение при получении эмбеддинга: {e}")
            # Возвращаем случайный вектор для тестирования
            return np.random.rand(1536).tolist()
    
    def process_query(self, query_text: str, user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Обрабатывает запрос пользователя, ищет релевантную информацию в базе данных
        и генерирует ответ с использованием DeepSeek API.
        """
        logger.info(f"Обработка запроса: {query_text}")
        
        try:
            # Генерация эмбеддинга для запроса
            query_embedding = self.generate_embedding(query_text)
            
            # Поиск релевантных документов по векторному представлению
            vector_search_results = self.db_manager.search_documents_by_vector(query_embedding, limit=3)
            
            # Поиск релевантных документов по тексту
            text_search_results = self.db_manager.search_documents_by_text(query_text, limit=3)
            
            # Объединение результатов поиска
            relevant_docs = []
            doc_ids = set()
            
            # Сначала добавляем результаты векторного поиска
            for doc, score in vector_search_results:
                if doc.id not in doc_ids and score > 0.7:  # Порог сходства
                    relevant_docs.append({
                        "id": doc.id,
                        "title": doc.title,
                        "content": doc.content,
                        "score": score
                    })
                    doc_ids.add(doc.id)
            
            # Затем добавляем результаты текстового поиска
            for doc in text_search_results:
                if doc.id not in doc_ids:
                    relevant_docs.append({
                        "id": doc.id,
                        "title": doc.title,
                        "content": doc.content,
                        "score": 0.0  # Для текстового поиска не используем score
                    })
                    doc_ids.add(doc.id)
            
            # Если не найдено релевантных документов, возвращаем сообщение об этом
            if not relevant_docs:
                response_text = "К сожалению, в базе данных не найдено релевантной информации по вашему запросу."
                
                # Сохраняем запрос в базе данных
                self.db_manager.create_query(
                    query_text=query_text,
                    query_vector=query_embedding,
                    user_id=user_id,
                    response_text=response_text,
                    relevant_document_ids=[]
                )
                
                return {
                    "query": query_text,
                    "response": response_text,
                    "relevant_docs": [],
                    "source": "no_data"
                }
            
            # Формируем контекст для запроса к DeepSeek API
            context = "Информация из базы данных:\n\n"
            for i, doc in enumerate(relevant_docs):
                context += f"Документ {i+1}: {doc['title']}\n{doc['content']}\n\n"
            
            # Формируем промпт для DeepSeek
            prompt = f"""На основе следующей информации из базы данных, ответьте на вопрос пользователя.
            
{context}

Вопрос пользователя: {query_text}

Ответ:"""
            
            # Генерация ответа с использованием DeepSeek API
            if self.api_key and self.api_key != "your_api_key_here":
                response_text = self._generate_response_with_api(prompt)
            else:
                # Если API ключ не настроен, формируем ответ на основе найденных документов
                response_text = self._generate_fallback_response(query_text, relevant_docs)
            
            # Сохраняем запрос в базе данных
            self.db_manager.create_query(
                query_text=query_text,
                query_vector=query_embedding,
                user_id=user_id,
                response_text=response_text,
                relevant_document_ids=[doc["id"] for doc in relevant_docs]
            )
            
            return {
                "query": query_text,
                "response": response_text,
                "relevant_docs": relevant_docs,
                "source": "deepseek_api" if (self.api_key and self.api_key != "your_api_key_here") else "fallback"
            }
        
        except Exception as e:
            logger.error(f"Ошибка при обработке запроса: {e}")
            return {
                "query": query_text,
                "response": f"Произошла ошибка при обработке запроса: {str(e)}",
                "relevant_docs": [],
                "source": "error"
            }
    
    def _generate_response_with_api(self, prompt: str) -> str:
        """Генерирует ответ с использованием DeepSeek API."""
        try:
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}"
            }
            
            data = {
                "model": self.model,
                "messages": [
                    {"role": "system", "content": "Вы - помощник, который отвечает на вопросы на основе предоставленной информации из базы данных."},
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0.7,
                "max_tokens": 1000
            }
            
            response = requests.post(
                f"{self.api_base_url}/chat/completions",
                headers=headers,
                json=data
            )
            
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"]
            else:
                logger.error(f"Ошибка при генерации ответа: {response.status_code} - {response.text}")
                return "Произошла ошибка при генерации ответа. Пожалуйста, попробуйте позже."
        
        except Exception as e:
            logger.error(f"Исключение при генерации ответа: {e}")
            return f"Произошла ошибка при генерации ответа: {str(e)}"
    
    def _generate_fallback_response(self, query: str, relevant_docs: List[Dict[str, Any]]) -> str:
        """
        Генерирует ответ на основе найденных документов без использования DeepSeek API.
        Используется как запасной вариант, если API ключ не настроен.
        """
        if not relevant_docs:
            return "К сожалению, в базе данных не найдено релевантной информации по вашему запросу."
        
        # Берем наиболее релевантный документ
        best_doc = relevant_docs[0]
        
        # Формируем простой ответ на основе содержимого документа
        response = f"На основе информации из базы данных:\n\n{best_doc['content']}"
        
        return response
    
    def add_document_with_embedding(self, title: str, content: str, 
                                   metadata: Optional[Dict[str, Any]] = None,
                                   source_type: Optional[str] = None) -> int:
        """
        Добавляет документ в базу данных с автоматической генерацией эмбеддинга.
        Возвращает ID созданного документа.
        """
        try:
            # Генерация эмбеддинга для содержимого документа
            content_embedding = self.generate_embedding(content)
            
            # Создание документа в базе данных
            document = self.db_manager.create_document(
                title=title,
                content=content,
                content_vector=content_embedding,
                metadata=metadata,
                source_type=source_type
            )
            
            logger.info(f"Документ '{title}' успешно добавлен в базу данных с ID {document.id}")
            return document.id
        
        except Exception as e:
            logger.error(f"Ошибка при добавлении документа с эмбеддингом: {e}")
            return -1
    
    def chunk_and_add_document(self, title: str, content: str, 
                              chunk_size: int = 1000, chunk_overlap: int = 200,
                              metadata: Optional[Dict[str, Any]] = None,
                              source_type: Optional[str] = None) -> int:
        """
        Разбивает документ на чанки и добавляет их в базу данных с эмбеддингами.
        Возвращает ID созданного документа.
        """
        try:
            # Создание документа в базе данных
            document = self.db_manager.create_document(
                title=title,
                content=content,
                metadata=metadata,
                source_type=source_type
            )
            
            # Разбиение содержимого на чанки
            chunks = self._split_text_into_chunks(content, chunk_size, chunk_overlap)
            
            # Добавление чанков в базу данных
            for i, chunk_text in enumerate(chunks):
                # Генерация эмбеддинга для чанка
                chunk_embedding = self.generate_embedding(chunk_text)
                
                # Создание чанка в базе данных
                self.db_manager.create_chunk(
                    document_id=document.id,
                    content=chunk_text,
                    content_vector=chunk_embedding,
                    chunk_index=i
                )
            
            # Обновление эмбеддинга для всего документа
            document_embedding = self.generate_embedding(content[:4000])  # Ограничиваем размер для эмбеддинга
            self.db_manager.update_document(
                document_id=document.id,
                content_vector=document_embedding
            )
            
            logger.info(f"Документ '{title}' успешно разбит на {len(chunks)} чанков и добавлен в базу данных с ID {document.id}")
            return document.id
        
        except Exception as e:
            logger.error(f"Ошибка при разбиении и добавлении документа: {e}")
            return -1
    
    def _split_text_into_chunks(self, text: str, chunk_size: int = 1000, chunk_overlap: int = 200) -> List[str]:
        """Разбивает текст на чанки указанного размера с перекрытием."""
        if not text:
            return []
        
        chunks = []
        start = 0
        text_length = len(text)
        
        while start < text_length:
            # Определяем конец текущего чанка
            end = min(start + chunk_size, text_length)
            
            # Если это не последний чанк и мы не достигли конца текста
            if end < text_length:
                # Ищем ближайший конец предложения или абзаца
                for delimiter in ['\n\n', '\n', '. ', '! ', '? ']:
                    last_delimiter = text.rfind(delimiter, start, end)
                    if last_delimiter != -1:
                        end = last_delimiter + len(delimiter)
                        break
            
            # Добавляем чанк в список
            chunks.append(text[start:end])
            
            # Перемещаем начало следующего чанка с учетом перекрытия
            start = end - chunk_overlap
            
            # Если начало следующего чанка слишком близко к концу текста, завершаем
            if start >= text_length - chunk_overlap:
                break
        
        return chunks
    
    def import_data_from_file(self, file_path: str, category: Optional[str] = None) -> int:
        """
        Импортирует данные из файла (CSV, JSON, TXT) в базу данных с генерацией эмбеддингов.
        Возвращает количество импортированных документов.
        """
        try:
            file_extension = os.path.splitext(file_path)[1].lower()
            
            if file_extension == '.csv':
                return self._import_from_csv(file_path, category)
            elif file_extension == '.json':
                return self._import_from_json(file_path, category)
            elif file_extension == '.txt':
                return self._import_from_txt(file_path, category)
            else:
                logger.error(f"Неподдерживаемый формат файла: {file_extension}")
                return 0
        
        except Exception as e:
            logger.error(f"Ошибка при импорте данных из файла: {e}")
            return 0
    
    def _import_from_csv(self, file_path: str, category: Optional[str] = None) -> int:
        """Импортирует данные из CSV-файла."""
        import pandas as pd
        
        try:
            df = pd.read_csv(file_path)
            
            # Проверка наличия необходимых столбцов
            required_columns = ['title', 'content']